speed = 0;
