hue = -20;
