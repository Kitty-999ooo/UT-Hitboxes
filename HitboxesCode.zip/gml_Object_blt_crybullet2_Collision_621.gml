disappear = 1;
