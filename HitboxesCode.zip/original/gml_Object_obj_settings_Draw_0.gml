global.menuno = 0;
string1 = undefined;
string2 = undefined;
string3 = undefined;
string4 = undefined;
string5 = undefined;
string6 = undefined;
string7 = undefined;
string8 = undefined;
string9 = undefined;
string10 = undefined;
string11 = undefined;
string12 = undefined;
string13 = undefined;
string14 = undefined;

if (!menu)
{
    string1 = string(ds_map_find_value(global.bbox_toggles, "player"));
    string2 = string(ds_map_find_value(global.bbox_toggles, "interact"));
    string3 = string(ds_map_find_value(global.bbox_toggles, "floorint"));
    string4 = string(ds_map_find_value(global.bbox_toggles, "transition"));
    string5 = string(ds_map_find_value(global.bbox_toggles, "solid"));
    string6 = string(ds_map_find_value(global.bbox_toggles, "sattack"));
    string7 = string(ds_map_find_value(global.bbox_toggles, "disabled"));
    string8 = string(ds_map_find_value(global.bbox_toggles, "trigger"));
    string9 = string(ds_map_find_value(global.bbox_toggles, "twall"));
    string10 = string(ds_map_find_value(global.bbox_toggles, "white"));
    string11 = string(ds_map_find_value(global.bbox_toggles, "2fwhite"));
    string12 = string(ds_map_find_value(global.bbox_toggles, "blue"));
    string13 = string(ds_map_find_value(global.bbox_toggles, "orange"));
    string14 = string(ds_map_find_value(global.bbox_toggles, "green"));
    DrawMenuOptionHM(0, 14, x, y + 280, "bbox mode - " + ds_map_find_value(global.bbox_toggles, "mode"), 65535, 16777215, 8421504);
}
else if (menu)
{
    string1 = string_replace(ds_map_find_value(global.bbox_colors, "player"), "#", "");
    string2 = string_replace(ds_map_find_value(global.bbox_colors, "interact"), "#", "");
    string3 = string_replace(ds_map_find_value(global.bbox_colors, "floorint"), "#", "");
    string4 = string_replace(ds_map_find_value(global.bbox_colors, "transition"), "#", "");
    string5 = string_replace(ds_map_find_value(global.bbox_colors, "solid"), "#", "");
    string6 = string_replace(ds_map_find_value(global.bbox_colors, "sattack"), "#", "");
    string7 = string_replace(ds_map_find_value(global.bbox_colors, "disabled"), "#", "");
    string8 = string_replace(ds_map_find_value(global.bbox_colors, "trigger"), "#", "");
    string9 = string_replace(ds_map_find_value(global.bbox_colors, "twall"), "#", "");
    string10 = string_replace(ds_map_find_value(global.bbox_colors, "white"), "#", "");
    string11 = string_replace(ds_map_find_value(global.bbox_colors, "2fwhite"), "#", "");
    string12 = string_replace(ds_map_find_value(global.bbox_colors, "blue"), "#", "");
    string13 = string_replace(ds_map_find_value(global.bbox_colors, "orange"), "#", "");
    string14 = string_replace(ds_map_find_value(global.bbox_colors, "green"), "#", "");
    DrawMenuOptionHM(0, 14, x, y + 280, "Reset to defaults", 255, 16777215, 8421504);
}

DrawMenuOptionHM(0, 0, x, y, "Player - " + string1, HexstringToColor(ds_map_find_value(global.bbox_colors, "player")), 16777215, 8421504);
DrawMenuOptionHM(0, 1, x, y + 20, "Interaction - " + string2, HexstringToColor(ds_map_find_value(global.bbox_colors, "interact")), 16777215, 8421504);
drawMenuOption(0, 2, x, y + 40, "Special Player - " + string3, HexstringToColor(ds_map_find_value(global.bbox_colors, "floorint")), 16777215, 8421504);
DrawMenuOptionHM(0, 3, x, y + 60, "Transitions - " + string4, HexstringToColor(ds_map_find_value(global.bbox_colors, "transition")), 16777215, 8421504);
DrawMenuOptionHM(0, 4, x, y + 80, "Wall - " + string5, HexstringToColor(ds_map_find_value(global.bbox_colors, "solid")), 16777215, 8421504);
DrawMenuOptionHM(0, 5, x, y + 100, "Cooking show attack - " + string6, HexstringToColor(ds_map_find_value(global.bbox_colors, "sattack")), 16777215, 8421504);
DrawMenuOptionHM(0, 6, x, y + 120, "Disabled - " + string7, HexstringToColor(ds_map_find_value(global.bbox_colors, "disabled")), 16777215, 8421504);
DrawMenuOptionHM(0, 7, x, y + 140, "Trigger - " + string8, HexstringToColor(ds_map_find_value(global.bbox_colors, "trigger")), 16777215, 8421504);
DrawMenuOptionHM(0, 8, x, y + 160, "Trigger with invisible wall - " + string9, HexstringToColor(ds_map_find_value(global.bbox_colors, "twall")), 16777215, 8421504);
DrawMenuOptionHM(0, 9, x, y + 180, "Normal attack - " + string10, HexstringToColor(ds_map_find_value(global.bbox_colors, "white")), 16777215, 8421504);
DrawMenuOptionHM(0, 10, x, y + 200, "2 frame interaction attack - " + string11, HexstringToColor(ds_map_find_value(global.bbox_colors, "2fwhite")), 16777215, 8421504);
DrawMenuOptionHM(0, 11, x, y + 220, "Blue attack - " + string12, HexstringToColor(ds_map_find_value(global.bbox_colors, "blue")), 16777215, 8421504);
DrawMenuOptionHM(0, 12, x, y + 240, "Orange attack - " + string13, HexstringToColor(ds_map_find_value(global.bbox_colors, "orange")), 16777215, 8421504);
DrawMenuOptionHM(0, 13, x, y + 260, "Green attack - " + string14, HexstringToColor(ds_map_find_value(global.bbox_colors, "green")), 16777215, 8421504);
