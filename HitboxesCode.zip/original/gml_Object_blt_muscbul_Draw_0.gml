draw_self_border();

if (y < 150)
    instance_destroy();

if (instance_exists(obj_muscbulgen))
    x = xs + round(sin(obj_muscbulgen.siner / 20) * 2);

bbox_create("white", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
