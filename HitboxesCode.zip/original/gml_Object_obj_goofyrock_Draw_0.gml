bbox_create("twall", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
bbox_create("interact", bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 0);
