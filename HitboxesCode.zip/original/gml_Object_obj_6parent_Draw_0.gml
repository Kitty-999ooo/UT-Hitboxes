if (sprite_index != -1 && object_index != obj_6gun)
    draw_self();

if (color == undefined)
    color = "white";

if (object_index == obj_6knife || object_index == obj_6glove_part)
{
    if (image_blend == c_lime)
        color = "green";
    else if (shake && object_index != obj_6glove_part)
        color = "disabled";
}
else if (object_index == obj_6gun_bullet && object_index.image_blend == c_lime)
{
    color = "green";
}

if (object_index == obj_6shoe_musicnote)
    color = "green";

if (object_index != obj_6shoe_musicnote && object_index != obj_6shoe_part)
{
    half_width = (right - left) / 2;
    half_height = (bottom - top) / 2;
    top_left_x = -half_width;
    top_left_y = -half_height;
    bottom_right_x = half_width;
    bottom_right_y = half_height;
    
    if (sprite_index == spr_6glove_thumbsup)
    {
        draw_sprite_ext(spr_glovebox, 0, x, y, image_xscale, image_yscale, image_angle, HexstringToColor(global.green), 1);
    }
    else
    {
        matrix_set(2, matrix_build(x, y, 0, 0, 0, image_angle, 1, 1, 1));
        
        if (object_index == obj_6glove_part)
        {
            hw = sprite_width / 2;
            hh = sprite_height / 2;
            l = -half_width;
            t = -half_height;
            r = half_width;
            b = half_height;
            bbox_create(color, l, t, r, b, 1, 0);
        }
        else
        {
            bbox_create(color, top_left_x, top_left_y, bottom_right_x, bottom_right_y, 1, 0);
        }
        
        matrix_set(2, matrix_build(0, 0, 0, 0, 0, 0, 1, 1, 1));
    }
}
else if ((object_index == obj_6shoe_part && object_index.y >= 180) || (object_index != obj_6shoe_part && object_index != obj_6glove_part))
{
    bbox_create(color, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
}
