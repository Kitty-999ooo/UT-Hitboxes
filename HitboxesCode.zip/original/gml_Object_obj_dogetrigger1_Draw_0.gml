draw_self_custom(0, room_width, 0, obj_dogehouse.y + 62);
bbox_create("trigger", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
