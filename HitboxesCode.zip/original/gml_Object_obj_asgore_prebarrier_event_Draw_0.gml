if (con == 50)
    bbox_create("trigger", 500, -10, 500, 250, 1, 0);
else
    bbox_create("trigger", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
