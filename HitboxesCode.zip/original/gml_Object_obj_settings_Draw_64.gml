option = global.menucoord[0] + 1;
draw_set_color(c_white);
draw_text(0, 0, "Settings");

if (option == 1)
    ohexn = "player";
else if (option == 2)
    ohexn = "interact";
else if (option == 3)
    ohexn = "floorint";
else if (option == 4)
    ohexn = "transition";
else if (option == 5)
    ohexn = "solid";
else if (option == 6)
    ohexn = "sattack";
else if (option == 7)
    ohexn = "disabled";
else if (option == 8)
    ohexn = "trigger";
else if (option == 9)
    ohexn = "twall";
else if (option == 10)
    ohexn = "white";
else if (option == 11)
    ohexn = "2fwhite";
else if (option == 12)
    ohexn = "blue";
else if (option == 13)
    ohexn = "orange";
else if (option == 14)
    ohexn = "green";

ohex = ds_map_find_value(global.bbox_colors, ohexn);

if (input)
{
    hex = string(hex);
    ohex = string(ohex);
    c = string_replace(hex, "\#", "");
    
    if (string_length(hex) < 4)
    {
        draw_set_color(c_white);
    }
    else if (string_length(c) < 2 || c == "0" || c == "00" || c == "000" || c == "0000" || c == "00000" || c == "000000")
    {
        draw_set_color(c_white);
        draw_text(225, 0, "Black");
    }
    else
    {
        draw_set_color(HexstringToColor(string_replace(hex, "\#", "#")));
    }
    
    draw_text(100, 0, "New Hex: " + hex);
    draw_set_color(HexstringToColor(ohex));
    draw_text(100, 15, "Old Hex: " + string_replace(ohex, "#", "\#"));
}
