draw_set_color(c_teal);
draw_rectangle(bbox_left, bbox_top, bbox_right, bbox_bottom, true);
