if (ds_map_find_value(global.bbox_toggles, "mode") == "hold")
    ds_map_replace(global.bbox_toggles, "active", 1);
