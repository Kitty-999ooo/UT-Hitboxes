if (obj_mainchara.x != obj_mainchara.xprevious || obj_mainchara.y != obj_mainchara.yprevious)
    helltrigger += 1;

bbox_create("trigger", bbox_left, bbox_top, bbox_right, bbox_bottom, 1);
