hex = "\#";
selection = undefined;
ds_map_find_value(global.bbox_toggles, "active");

if (!menu)
{
    ini_open("HitboxesSettings.ini");
    
    if (option == 1)
    {
        selection = "player";
    }
    else if (option == 2)
    {
        selection = "interact";
    }
    else if (option == 3)
    {
        selection = "floorint";
    }
    else if (option == 4)
    {
        selection = "transition";
    }
    else if (option == 5)
    {
        selection = "solid";
    }
    else if (option == 6)
    {
        selection = "sattack";
    }
    else if (option == 7)
    {
        selection = "disabled";
    }
    else if (option == 8)
    {
        selection = "trigger";
    }
    else if (option == 9)
    {
        selection = "twall";
    }
    else if (option == 10)
    {
        selection = "white";
    }
    else if (option == 11)
    {
        selection = "2fwhite";
    }
    else if (option == 12)
    {
        selection = "blue";
    }
    else if (option == 13)
    {
        selection = "orange";
    }
    else if (option == 14)
    {
        selection = "green";
    }
    else if (option == 15)
    {
        mode = ds_map_find_value(global.bbox_toggles, "mode");
        
        if (mode == "toggle")
        {
            mode = "hold";
            bboxmode = 0;
        }
        else if (mode == "hold")
        {
            mode = "toggle";
            bboxmode = 1;
        }
        
        ds_map_replace(global.bbox_toggles, "mode", mode);
        ini_write_real("Keyboard options", "bbox mode", bboxmode);
        exit;
    }
    
    ds_map_replace(global.bbox_toggles, selection, !ds_map_find_value(global.bbox_toggles, selection));
    ini_write_real("Toggles", selection, ds_map_find_value(global.bbox_toggles, selection));
    ini_close();
}
else if (menu)
{
    if (option == 15)
    {
        file_delete("HitboxesColors");
        elif = file_text_open_write("HitboxesColors");
        file_text_write_string(elif, "#ffff00");
        file_text_writeln(elif);
        file_text_write_string(elif, "#800080");
        file_text_writeln(elif);
        file_text_write_string(elif, "#00ff00");
        file_text_writeln(elif);
        file_text_write_string(elif, "#00ffff");
        file_text_writeln(elif);
        file_text_write_string(elif, "#0000ff");
        file_text_writeln(elif);
        file_text_write_string(elif, "#000080");
        file_text_writeln(elif);
        file_text_write_string(elif, "#808080");
        file_text_writeln(elif);
        file_text_write_string(elif, "#ff00ff");
        file_text_writeln(elif);
        file_text_write_string(elif, "#008080");
        file_text_writeln(elif);
        file_text_write_string(elif, "#ff0000");
        file_text_writeln(elif);
        file_text_write_string(elif, "#800000");
        file_text_writeln(elif);
        file_text_write_string(elif, "#a500ff");
        file_text_writeln(elif);
        file_text_write_string(elif, "#5aff00");
        file_text_writeln(elif);
        file_text_write_string(elif, "#160dff");
        file_text_close(elif);
        ds_map_replace(global.bbox_colors, "player", "#ffff00");
        ds_map_replace(global.bbox_colors, "interact", "#800080");
        ds_map_replace(global.bbox_colors, "floorint", "#00ff00");
        ds_map_replace(global.bbox_colors, "transition", "#00ffff");
        ds_map_replace(global.bbox_colors, "solid", "#0000ff");
        ds_map_replace(global.bbox_colors, "sattack", "#000080");
        ds_map_replace(global.bbox_colors, "disabled", "#808080");
        ds_map_replace(global.bbox_colors, "trigger", "#ff00ff");
        ds_map_replace(global.bbox_colors, "twall", "#008080");
        ds_map_replace(global.bbox_colors, "white", "#ff0000");
        ds_map_replace(global.bbox_colors, "2fwhite", "#800000");
        ds_map_replace(global.bbox_colors, "blue", "#a500ff");
        ds_map_replace(global.bbox_colors, "orange", "#5aff00");
        ds_map_replace(global.bbox_colors, "green", "#160dff");
    }
    else
    {
        input = 1;
    }
}
