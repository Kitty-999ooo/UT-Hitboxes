draw_self_border();
d3d_set_fog(true, HexstringToColor(ds_map_find_value(global.bbox_colors, "white")), 0, 0);
draw_sprite(spr_vertplanemask, 0, x, y);
d3d_set_fog(false, c_black, 0, 0);
