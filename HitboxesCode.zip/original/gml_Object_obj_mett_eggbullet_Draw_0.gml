bbox_create("sattack", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
