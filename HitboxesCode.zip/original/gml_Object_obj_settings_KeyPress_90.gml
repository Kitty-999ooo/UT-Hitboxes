if (!input)
    confirmsettings();
