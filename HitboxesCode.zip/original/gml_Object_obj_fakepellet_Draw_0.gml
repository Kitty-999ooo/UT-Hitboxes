bbox_create("white", bbox_left + 4, bbox_top + 4, bbox_right - 4, bbox_bottom - 4, 1, 1);
