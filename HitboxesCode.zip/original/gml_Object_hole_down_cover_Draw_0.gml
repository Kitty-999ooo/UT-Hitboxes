if (ds_map_find_value(global.bbox_toggles, "active") && ds_map_find_value(global.bbox_toggles, "trigger"))
{
    d3d_set_fog(true, HexstringToColor(ds_map_find_value(global.bbox_colors, "trigger")), 0, 0);
    draw_self();
    d3d_set_fog(false, c_black, 0, 0);
}
