draw_self_border();
bbox_create("blue", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
