draw_self();
draw_sprite_ext(spr_roachBox, 0, x, y, 1, 1, 0, HexstringToColor(ds_map_find_value(global.bbox_colors, "white")), 1);
