if (!input)
{
    if (global.menucoord[0] > 0)
        global.menucoord[0] -= 1;
    else
        global.menucoord[0] = noofoptions - 1;
}
