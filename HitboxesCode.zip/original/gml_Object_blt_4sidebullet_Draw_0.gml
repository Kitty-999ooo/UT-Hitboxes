draw_self_border();
direction += rotdir;
scr_bordercross(12);
image_alpha += 0.1;
bbox_create("white", bbox_left - 1, bbox_top - 1, bbox_right, bbox_bottom, 1, 0);
