xx = view_xview[0];
yy = view_yview[0];
draw_sprite(sprite_index, image_index, x, y);
timertime -= 1;

if (timertime < 300)
    timertime += 0.25;

bbox_create("player", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
