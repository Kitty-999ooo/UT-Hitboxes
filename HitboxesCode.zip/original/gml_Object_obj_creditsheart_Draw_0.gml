draw_sprite(sprite_index, image_index, x, y);

if (keyboard_check(vk_right))
    x += 4;

if (keyboard_check(vk_up))
    y -= 4;

if (keyboard_check(vk_down))
    y += 4;

if (keyboard_check(vk_left))
    x -= 4;

if (x > 624)
    x = 624;

if (x < 0)
    x = 0;

if (y > 464)
    y = 464;

if (y < 0)
    y = 0;

bbox_create("player", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
