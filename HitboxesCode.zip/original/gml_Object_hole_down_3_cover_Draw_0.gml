image_blend = HexstringToColor(ds_map_find_value(global.bbox_colors, "trigger"));

if (ds_map_find_value(global.bbox_toggles, "active") && ds_map_find_value(global.bbox_toggles, "trigger"))
    draw_self();
