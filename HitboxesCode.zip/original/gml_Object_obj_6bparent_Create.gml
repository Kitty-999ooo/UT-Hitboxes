shake = 0;
color = "white";
