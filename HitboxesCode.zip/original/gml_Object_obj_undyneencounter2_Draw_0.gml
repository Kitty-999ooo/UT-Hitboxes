bbox_create("trigger", bbox_left + 12, -5, bbox_right + 12, 250, 1, 0);
bbox_create("trigger", 780, 100, 790, 900, 1, 0);
