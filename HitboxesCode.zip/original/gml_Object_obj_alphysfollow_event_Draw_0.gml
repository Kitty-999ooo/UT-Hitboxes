bbox_create("trigger", 420, -10, 420, 250, 1, 0);

if (nowx < 764)
    bbox_create("trigger", nowx + 220, -10, nowx + 220, 250, 1, 0);
