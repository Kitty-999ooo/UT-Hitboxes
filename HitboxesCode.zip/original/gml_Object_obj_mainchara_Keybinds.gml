if (global.debug)
{
    if (keyboard_lastkey == global.keybindSave)
    {
        global.interact = 5;
        global.menuno = 4;
    }
    else if (keyboard_lastkey == global.keybindLoad)
    {
        script_execute(scr_load);
        obj_time.reset = 1;
        
        if (global.resetini)
        {
            if (file_exists("undertale.ini"))
                file_delete("undertale.ini");
            
            if (file_exists("utoriginal.ini"))
                file_copy("utoriginal.ini", "undertale.ini");
        }
    }
    else if (keyboard_lastkey == global.keybindRestartRoom)
    {
        room_restart();
    }
    else if (keyboard_lastkey == global.keybindNoclip)
    {
        global.interact = 0;
        global.phasing++;
        
        if (global.phasing > 1)
            global.phasing = 0;
    }
    else if (keyboard_lastkey == global.keybindMute)
    {
        caster_free(all);
    }
    else if (keyboard_lastkey == global.keybindStartBattle)
    {
        global.battlegroup = 80 + nnn;
        global.border = 0;
        instance_create(0, 0, obj_battleblcon);
        
        if (global.plot == 998)
        {
            global.flag[10] = 0;
            global.flag[11] = 0;
            global.flag[12] = 0;
            global.flag[13] = 0;
            global.entrance = 0;
            global.battlegroup = 82;
            obj_mainchara.depth = -600;
            
            if (instance_exists(obj_battler) == 0)
                instance_create(0, 0, obj_battler);
        }
    }
}

if (keyboard_lastkey == ord("Y"))
    y -= 1;
else if (keyboard_lastkey == ord("H"))
    y += 1;
else if (keyboard_lastkey == ord("G"))
    x -= 1;
else if (keyboard_lastkey == ord("J"))
    x += 1;
