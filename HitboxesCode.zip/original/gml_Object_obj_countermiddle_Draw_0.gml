if (instance_exists(obj_mettaton_npc) && global.facing == 0)
{
    if (obj_mettaton_npc.sugar == 1 && obj_mettaton_npc.eggs == 1 && obj_mettaton_npc.milk == 1)
        color = "interact";
}
else
{
    color = "disabled";
}

bbox_create(color, bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 0);
