draw_self();

if (obj_mainchara.x > x)
    y = yy;

if (con == -1)
    bbox_create("trigger", x + 20, -10, x + 20, 250, 1, 0);
