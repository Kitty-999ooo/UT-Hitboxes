draw_self_border();

if (y < 344)
{
    comment = "top";
    bbox_create("white", bbox_left, bbox_top, bbox_right, bbox_top, 1, 0, "line");
    bbox_create("white", bbox_left, bbox_top, x + (sprite_width / 2), bbox_bottom, 1, 0, "line");
    bbox_create("white", bbox_right, bbox_top, x + (sprite_width / 2), bbox_bottom, 1, 0, "line");
}
else
{
    comment = "bottom";
    bbox_create("white", bbox_left, bbox_bottom, bbox_right, bbox_bottom, 1, 0, "line");
    bbox_create("white", bbox_left, bbox_bottom, x + (sprite_width / 2), bbox_top, 1, 0, "line");
    bbox_create("white", bbox_right, bbox_bottom, x + (sprite_width / 2), bbox_top, 1, 0, "line");
}
