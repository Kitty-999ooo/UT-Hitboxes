bbox_create("white", x + 91, y + 93, x + 128, y + 158, 1, 1);
bbox_create("white", x + 88, y + 68, x + 128, y + 158, 1, 0);
bbox_create("white", x + 80, y + 44, x + 128, y + 158, 1, 0);
bbox_create("white", x + 70, y + 28, x + 118, y + 158, 1, 0);
