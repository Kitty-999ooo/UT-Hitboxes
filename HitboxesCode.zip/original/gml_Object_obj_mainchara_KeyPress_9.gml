if (ds_map_find_value(global.bbox_toggles, "mode") == "toggle")
    ds_map_replace(global.bbox_toggles, "active", !ds_map_find_value(global.bbox_toggles, "active"));
else
    ds_map_replace(global.bbox_toggles, "active", 0);
