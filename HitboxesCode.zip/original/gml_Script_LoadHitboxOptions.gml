global.bbox_colors = ds_map_create();
global.bbox_toggles = ds_map_create();

if (file_exists("HitboxesSettings.ini"))
{
    ini_open("HitboxesSettings.ini");
    ds_map_add(global.bbox_toggles, "player", ini_read_real("Toggles", "player", 0));
    ds_map_add(global.bbox_toggles, "interact", ini_read_real("Toggles", "interact", 0));
    ds_map_add(global.bbox_toggles, "floorint", ini_read_real("Toggles", "special player", 0));
    ds_map_add(global.bbox_toggles, "transition", ini_read_real("Toggles", "transition", 0));
    ds_map_add(global.bbox_toggles, "solid", ini_read_real("Toggles", "solid", 0));
    ds_map_add(global.bbox_toggles, "sattack", ini_read_real("Toggles", "cooking show attack", 0));
    ds_map_add(global.bbox_toggles, "disabled", ini_read_real("Toggles", "disabled", 0));
    ds_map_add(global.bbox_toggles, "trigger", ini_read_real("Toggles", "trigger", 0));
    ds_map_add(global.bbox_toggles, "twall", ini_read_real("Toggles", "inviswall", 0));
    ds_map_add(global.bbox_toggles, "white", ini_read_real("Toggles", "white attack", 0));
    ds_map_add(global.bbox_toggles, "2fwhite", ini_read_real("Toggles", "frame2 attack", 0));
    ds_map_add(global.bbox_toggles, "blue", ini_read_real("Toggles", "blue attack", 0));
    ds_map_add(global.bbox_toggles, "orange", ini_read_real("Toggles", "orange attack", 0));
    ds_map_add(global.bbox_toggles, "green", ini_read_real("Toggles", "green attack", 0));
    bboxmode = ini_read_real("Keyboard options", "bbox mode", 0);
    
    if (bboxmode)
        ds_map_add(global.bbox_toggles, "mode", "toggle");
    else
        ds_map_add(global.bbox_toggles, "mode", "hold");
    
    ds_map_add(global.bbox_toggles, "active", 1);
    ini_close();
}
else
{
    ini_open("HitboxesSettings.ini");
    ini_write_real("Toggles", "player", 1);
    ini_write_real("Toggles", "interact", 1);
    ini_write_real("Toggles", "special player", 1);
    ini_write_real("Toggles", "transition", 1);
    ini_write_real("Toggles", "solid", 1);
    ini_write_real("Toggles", "cooking show attack", 1);
    ini_write_real("Toggles", "disabled", 1);
    ini_write_real("Toggles", "trigger", 1);
    ini_write_real("Toggles", "inviswall", 1);
    ini_write_real("Toggles", "white attack", 1);
    ini_write_real("Toggles", "frame2 attack", 1);
    ini_write_real("Toggles", "blue attack", 1);
    ini_write_real("Toggles", "orange attack", 1);
    ini_write_real("Toggles", "green attack", 1);
    ini_write_real("Keyboard options", "bbox mode", 1);
    ds_map_add(global.bbox_toggles, "player", 1);
    ds_map_add(global.bbox_toggles, "interact", 1);
    ds_map_add(global.bbox_toggles, "floorint", 1);
    ds_map_add(global.bbox_toggles, "transition", 1);
    ds_map_add(global.bbox_toggles, "solid", 1);
    ds_map_add(global.bbox_toggles, "sattack", 1);
    ds_map_add(global.bbox_toggles, "disabled", 1);
    ds_map_add(global.bbox_toggles, "trigger", 1);
    ds_map_add(global.bbox_toggles, "twall", 1);
    ds_map_add(global.bbox_toggles, "white", 1);
    ds_map_add(global.bbox_toggles, "2fwhite", 1);
    ds_map_add(global.bbox_toggles, "blue", 1);
    ds_map_add(global.bbox_toggles, "orange", 1);
    ds_map_add(global.bbox_toggles, "green", 1);
    ds_map_add(global.bbox_toggles, "mode", "toggle");
    ds_map_add(global.bbox_toggles, "active", 1);
    ini_close();
}

if (!file_exists("HitboxesColors"))
{
    elif = file_text_open_write("HitboxesColors");
    file_text_write_string(elif, "#ffff00");
    file_text_writeln(elif);
    file_text_write_string(elif, "#800080");
    file_text_writeln(elif);
    file_text_write_string(elif, "#00ff00");
    file_text_writeln(elif);
    file_text_write_string(elif, "#00ffff");
    file_text_writeln(elif);
    file_text_write_string(elif, "#0000ff");
    file_text_writeln(elif);
    file_text_write_string(elif, "#000080");
    file_text_writeln(elif);
    file_text_write_string(elif, "#808080");
    file_text_writeln(elif);
    file_text_write_string(elif, "#ff00ff");
    file_text_writeln(elif);
    file_text_write_string(elif, "#008080");
    file_text_writeln(elif);
    file_text_write_string(elif, "#ff0000");
    file_text_writeln(elif);
    file_text_write_string(elif, "#800000");
    file_text_writeln(elif);
    file_text_write_string(elif, "#a500ff");
    file_text_writeln(elif);
    file_text_write_string(elif, "#5aff00");
    file_text_writeln(elif);
    file_text_write_string(elif, "#160dff");
    ds_map_add(global.bbox_colors, "player", "#ffff00");
    ds_map_add(global.bbox_colors, "interact", "#800080");
    ds_map_add(global.bbox_colors, "floorint", "#00ff00");
    ds_map_add(global.bbox_colors, "transition", "#00ffff");
    ds_map_add(global.bbox_colors, "solid", "#0000ff");
    ds_map_add(global.bbox_colors, "sattack", "#000080");
    ds_map_add(global.bbox_colors, "disabled", "#808080");
    ds_map_add(global.bbox_colors, "trigger", "#ff00ff");
    ds_map_add(global.bbox_colors, "twall", "#008080");
    ds_map_add(global.bbox_colors, "white", "#ff0000");
    ds_map_add(global.bbox_colors, "2fwhite", "#800000");
    ds_map_add(global.bbox_colors, "blue", "#a500ff");
    ds_map_add(global.bbox_colors, "orange", "#5aff00");
    ds_map_add(global.bbox_colors, "green", "#160dff");
}
else
{
    elif = file_text_open_read("HitboxesColors");
    ds_map_add(global.bbox_colors, "player", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "interact", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "floorint", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "transition", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "solid", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "sattack", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "disabled", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "trigger", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "twall", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "white", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "2fwhite", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "blue", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "orange", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "green", file_text_read_string(elif));
    file_text_readln(elif);
}

file_text_close(elif);
