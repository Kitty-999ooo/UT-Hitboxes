if (!input)
{
    elif = file_text_open_write("HitboxesColors");
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "player"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "interact"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "floorint"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "transition"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "solid"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "sattack"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "disabled"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "trigger"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "twall"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "white"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "2fwhite"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "blue"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "orange"));
    file_text_writeln(elif);
    file_text_write_string(elif, ds_map_find_value(global.bbox_colors, "green"));
    file_text_close(elif);
    room_goto(room_introstory);
}
