if (myinteract != 0)
{
    siner += 1;
    y -= (cos(siner / 3) * 0.6);
    image_yscale = 1 + (sin(siner / 3) * 0.1);
    image_xscale = 1 - (sin(siner / 3) * 0.05);
}
else
{
    siner = 0;
    image_yscale = 1;
    image_xscale = 1;
    y = ystart;
}

draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, 0, c_white, image_alpha);
bbox_create("solid", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
bbox_create("interact", bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 0);
