if (ds_map_find_value(global.bbox_toggles, "active") && ds_map_find_value(global.bbox_toggles, "trigger"))
{
    d3d_set_fog(true, HexstringToColor(ds_map_find_value(global.bbox_colors, "trigger")), 0, 0);
    draw_self();
    d3d_set_fog(false, c_black, 0, 0);
    scale = 0.9;
    draw_sprite_ext(sprite_index, 0, x + ((sprite_width - (sprite_width * scale)) / 2), y + ((sprite_height - (sprite_height * scale)) / 2), scale, scale, 0, c_white, 1);
}
else
{
    draw_self();
}
