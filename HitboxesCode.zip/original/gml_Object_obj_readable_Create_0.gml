myinteract = 0;
visible = true;
