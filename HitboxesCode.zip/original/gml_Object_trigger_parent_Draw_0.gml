color = "trigger";

if (collision_rectangle(obj_mainchara.bbox_left, obj_mainchara.bbox_top, obj_mainchara.bbox_right, obj_mainchara.bbox_bottom, obj_indryspot, 0, 0) && object_index == obj_inwaterspot)
    color = "disabled";

if (object_index == obj_holeup || object_index == obj_holeup2)
{
    if (global.phasing != 0 || global.interact != 0)
        color = "disabled";
}

bbox_create(color, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
