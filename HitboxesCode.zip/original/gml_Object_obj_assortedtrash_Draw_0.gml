bbox_create("solid", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
bbox_create("interact", bbox_left - 1, bbox_top - 3, bbox_right + 3, bbox_bottom + 2, 1, 0);
