if (blue == 1)
    type = "blue";
else if (blue == 3)
    type = "green";
else
    type = "white";

bbox_create(type, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
