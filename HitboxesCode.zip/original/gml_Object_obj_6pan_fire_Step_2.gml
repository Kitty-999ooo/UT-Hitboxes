ny = y - prevy;

if (image_blend == c_lime)
{
    if (ny >= 5)
        b = 6;
    else if (ny >= 3)
        b = 3;
    else
        b = 0;
}
