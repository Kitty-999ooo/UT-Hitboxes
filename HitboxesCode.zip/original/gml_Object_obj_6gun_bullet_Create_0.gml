image_xscale = 2;
image_yscale = 2;
type = 0;
left = bbox_left;
right = bbox_right;
top = bbox_top;
bottom = bbox_bottom;
color = "white";
