type = "twall";

if (x != 60)
    type = "trigger";

bbox_create(type, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
