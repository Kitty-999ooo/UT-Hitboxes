caster_stop(menusong);
global.menucoord[0] = 0;
room_goto(room_settings);
