fleft = 252;
fright = 270;
fbottom = 76;
ftop = 61;
sleft = 268;
sright = 276;
sbottom = 135;
stop = 105;

if (con < 63)
    bbox_create("trigger", -10, 230, 330, 230, 1, 0);

if (itemsexist)
{
    bbox_create("interact", teabox.bbox_left, teabox.bbox_top, teabox.bbox_right, teabox.bbox_bottom, 1, 0);
    bbox_create("interact", hotchocolate.bbox_left, hotchocolate.bbox_top, hotchocolate.bbox_right, hotchocolate.bbox_bottom, 1, 0);
    bbox_create("interact", soda.bbox_left, soda.bbox_top, soda.bbox_right, soda.bbox_bottom, 1, 0);
    bbox_create("interact", sugar.bbox_left, sugar.bbox_top, sugar.bbox_right, sugar.bbox_bottom, 1, 0);
    bbox_create("interact", undyne.bbox_left, undyne.bbox_top, undyne.bbox_right, undyne.bbox_bottom, 1, 0);
    bbox_create("interact", fleft, ftop, fright, fbottom, 1, 0);
    bbox_create("interact", sleft, stop, sright, sbottom, 1, 0);
}
