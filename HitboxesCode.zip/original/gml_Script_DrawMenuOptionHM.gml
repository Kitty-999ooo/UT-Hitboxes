comment = "this is a duplicate of the draw manu option function in the practice mod (compatability reasons)";
comment = "drawMenuOption(menuno, menucoord, x, y, text, hover color (= c_yellow), normal color (= c_white), inactive color (= c_gray)";

if (argument_count > 5)
{
    hoverColor = argument5;
    normalColor = argument6;
    inactiveColor = argument7;
}
else
{
    hoverColor = 65535;
    normalColor = 16777215;
    inactiveColor = 8421504;
}

if (global.menuno != argument0 || global.textInputActive)
{
    if (global.menuno >= argument0 && global.menucoord[argument0] == argument1)
        draw_set_color(merge_color(hoverColor, inactiveColor, 0.5));
    else
        draw_set_color(inactiveColor);
}
else if (global.menucoord[argument0] == argument1)
{
    draw_set_color(hoverColor);
}
else
{
    draw_set_color(normalColor);
}

draw_text(argument2, argument3, argument4);

if (global.menuno == argument0 && global.menucoord[global.menuno] == argument1)
    draw_sprite(spr_heartsmall, 0, argument2 - 12, argument3 + 4);

global.menulength[argument0] = argument1;
