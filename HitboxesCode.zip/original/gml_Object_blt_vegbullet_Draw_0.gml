color = "white";

if (green)
    color = "green";

bbox_create(color, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
