draw_self();
color = "white";

if ((object_index == obj_floweyx_flame && image_index == 0) || (object_index == obj_floweyx_flame && image_index == 1) || (object_index == obj_floweyx_flame && image_index >= 16))
    color = "disabled";

if (object_index != obj_floweyx_flamethrower)
    bbox_create(color, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
