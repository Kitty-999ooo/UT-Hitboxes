bbox_create("trigger", bbox_left, 0, bbox_right, 1250, 1, 0);
