extrab = 0;
extral = 0;
extrat = 0;

if (room == room_fire1)
{
    extrab = 65;
    extral = 4;
    extrat = 61;
}

bbox_create("trigger", (bbox_left + 2) - extral, (bbox_top + 5) - extrat, bbox_right, (bbox_bottom - 3) + extrab, 1, 1);
