prevy = y;
