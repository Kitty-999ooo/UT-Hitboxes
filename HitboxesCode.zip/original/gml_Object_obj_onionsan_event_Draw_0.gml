if (global.flag[496] <= 4)
    visible = true;
else
    visible = false;

xlocation = 100;
fullLocation = (1 + obj_mainchara.bbox_right) - obj_mainchara.bbox_left;
bbox_create("trigger", xlocation + fullLocation, 0, xlocation + fullLocation, 250, 1, 0);
xlocation = 210;
bbox_create("trigger", xlocation + fullLocation, 0, xlocation + fullLocation, 250, 1, 0);
xlocation = 420;
bbox_create("trigger", xlocation + fullLocation, 0, xlocation + fullLocation, 250, 1, 0);
xlocation = 550;
bbox_create("trigger", xlocation + fullLocation, 0, xlocation + fullLocation, 250, 1, 0);
xlocation = 700;
bbox_create("trigger", xlocation + fullLocation, 0, xlocation + fullLocation, 250, 1, 0);
xlocation = 850;
bbox_create("trigger", xlocation + fullLocation, 0, xlocation + fullLocation, 250, 1, 0);
xlocation = 1000;
bbox_create("trigger", xlocation + fullLocation, 0, xlocation + fullLocation, 250, 1, 0);
