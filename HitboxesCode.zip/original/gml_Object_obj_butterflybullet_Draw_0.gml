color = "white";

if (green == 0)
    color = "white";

if (green == 1)
    color = "green";

bbox_create(color, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
