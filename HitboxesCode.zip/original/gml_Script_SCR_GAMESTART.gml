randomize();
audio_channel_num(128);
global.awfultest = 0;
global.steam_int = 0;

if (steam_initialised())
{
    global.steam_int = 1;
    
    if (steam_file_exists("system_information_962"))
    {
        exd = file_text_open_write("system_information_962");
        file_text_write_string(exd, "a");
        file_text_close(exd);
    }
    
    if (steam_file_exists("system_information_963"))
    {
        exd = file_text_open_write("system_information_963");
        file_text_write_string(exd, "b");
        file_text_close(exd);
        
        if (file_exists("system_information_962"))
            file_delete("system_information_962");
        
        if (steam_file_exists("system_information_962"))
            steam_file_delete("system_information_962");
    }
}

global.hp = 20;
global.maxhp = 20;
global.en = 20;
global.maxen = 20;
global.at = 10;
global.df = 10;
global.adef = 0;
global.sp = 4;
global.asp = 4;
global.hb = 5;
global.gt = 5;
global.km = 0;
global.ph = 0;
global.gold = 0;
global.xp = 0;
global.lv = 1;
global.area = 0;
global.charname = "CHARA";
global.menuno = -1;

for (i = 0; i < 8; i += 1)
{
    global.item[i] = 0;
    global.spell[i] = 1;
    global.bulletvariable[i] = 0;
    global.bmenuno = 0;
    global.bmenucoord[i] = 0;
}

for (i = 0; i < 27; i += 1)
{
    global.menucoord[i] = 0;
    global.menulength[i] = 0;
}

for (i = 0; i < 24; i += 1)
    global.areapop[i] = 0;

for (i = 0; i < 99; i += 1)
    global.msg[i] = "%%%";

global.area = 0;

for (i = 0; i < 512; i += 1)
    global.flag[i] = 0;

global.flag[300] = 14;
global.flag[301] = 0;
global.flag[302] = 0;
global.flag[303] = 0;
global.flag[304] = 0;
global.flag[512] = 0;
global.idealborder[0] = 0;
global.idealborder[1] = 0;
global.idealborder[2] = 0;
global.idealborder[3] = 0;
global.plot = 0;
global.currentroom = room_start;

for (i = 0; i < 3; i += 1)
{
    global.monstername[i] = "Error";
    global.monsterhp[i] = 50;
    global.monstermaxhp[i] = 50;
    global.monsterdef[i] = 0;
    global.xpreward[i] = 0;
    global.goldreward[i] = 0;
    global.itemrewardid[i] = 0;
    global.itemrewardchance[i] = 0;
    global.monster[i] = 0;
    global.attacker[i] = 0;
    global.mnpwr[i] = 0;
    global.bulletpwr[i] = 0;
    global.hurtanim[i] = 0;
}

for (i = 0; i < 4; i += 1)
    global.atkchoice[i] = 1;

global.xpreward[3] = 0;
global.goldreward[3] = 0;
global.battlegroup = 3;
global.turntimer = 0;
global.talked = 0;
global.inv = 20;
global.invc = 0;
global.turnmax = 0;
global.myfight = 0;
global.mnfight = 0;
global.incombat = 0;
global.firingrate = 14;
global.border = 0;
global.turn = 0;
global.actfirst = 0;
global.extraintro = 0;
global.mytarget = 0;
global.confirm = "ord('z')";
global.damagetimer = 90;
global.attacktype = 1;
global.wstrength = 0;
global.pwr = 0;
global.attackspeed = 11;
global.attackspeedr = 2;
global.wstrength = 0;
global.kills = 0;
global.specialbattle = 0;
global.batmusic = 43872483278;
global.myview = 0;
global.hshake = 0;
global.vshake = 0;
global.shakespeed = 0;
global.encounter = 0;
global.facing = 0;
global.phasing = 0;
global.choices = 0;
global.interact = 0;
global.viewpan = 0;
global.inbattle = 0;
global.facechoice = 0;
global.faceemotion = 0;
global.seriousbattle = 0;
global.mercy = 0;
global.item[0] = 0;
global.item[1] = 0;
global.item[2] = 0;
global.item[3] = 0;
global.item[4] = 0;
global.item[5] = 0;
global.item[6] = 0;
global.item[7] = 0;
global.item[8] = 0;
global.weapon = 3;
global.armor = 4;
global.phone[0] = 0;
global.phone[1] = 0;
global.phone[2] = 0;
global.phone[3] = 0;
global.phone[4] = 0;
global.phone[5] = 0;
global.phone[6] = 0;
global.phone[7] = 0;
global.phone[8] = 0;
global.menuchoice[0] = 1;
global.menuchoice[1] = 1;
global.menuchoice[2] = 0;
global.menuchoice[3] = 0;
global.choice = -1;
global.lastsavedtime = 0;
global.lastsavedkills = 0;
global.lastsavedlv = 0;
global.dontfade = 0;
global.entrance = 0;
global.currentsong = -1;
global.currentsong2 = -1;
global.currentsongv = 1;
global.currentsongi = -1;
global.batmusic = -1;
global.batmusici = -1;
global.typer = 5;
global.msc = 0;
global.hardmode = 0;
file_rename("data/unused/dfb", "data/unused/dfb.png");
global.background = background_add("data/unused/dfb.png", 0, 1);
file_rename("data/unused/dfb.png", "data/unused/dfb");
global.previousRoom = 0;
global.textInputActive = 0;
global.textInputState = 0;
global.textInputError = "";
global.dummyPractice = 0;
global.dummyFrames = -100;
loadPracticeOptions();
global.debugTemp = global.debug;
global.savestatesTemp = global.savestates;
global.fixedblcon = -1;
global.monstertaleSkippable = 0;
global.weaponPracticeMode = 0;
global.weaponPracticeBoss = 0;
global.weaponPracticeInv = 0;
global.weaponPracticePlayerInv = 0;
global.weaponPracticeAttacks = 0;
global.weaponPracticeMttRatings = 1;
global.weaponPracticeSimulateBoss = 1;
global.weaponPracticeTurnGoal = 0;
global.bbox_colors = ds_map_create();
global.bbox_toggles = ds_map_create();

if (file_exists("HitboxesSettings.ini"))
{
    ini_open("HitboxesSettings.ini");
    ds_map_add(global.bbox_toggles, "player", ini_read_real("Toggles", "player", 0));
    ds_map_add(global.bbox_toggles, "interact", ini_read_real("Toggles", "interact", 0));
    ds_map_add(global.bbox_toggles, "floorint", ini_read_real("Toggles", "special player", 0));
    ds_map_add(global.bbox_toggles, "transition", ini_read_real("Toggles", "transition", 0));
    ds_map_add(global.bbox_toggles, "solid", ini_read_real("Toggles", "solid", 0));
    ds_map_add(global.bbox_toggles, "sattack", ini_read_real("Toggles", "cooking show attack", 0));
    ds_map_add(global.bbox_toggles, "disabled", ini_read_real("Toggles", "disabled", 0));
    ds_map_add(global.bbox_toggles, "trigger", ini_read_real("Toggles", "trigger", 0));
    ds_map_add(global.bbox_toggles, "twall", ini_read_real("Toggles", "inviswall", 0));
    ds_map_add(global.bbox_toggles, "white", ini_read_real("Toggles", "white attack", 0));
    ds_map_add(global.bbox_toggles, "2fwhite", ini_read_real("Toggles", "frame2 attack", 0));
    ds_map_add(global.bbox_toggles, "blue", ini_read_real("Toggles", "blue attack", 0));
    ds_map_add(global.bbox_toggles, "orange", ini_read_real("Toggles", "orange attack", 0));
    ds_map_add(global.bbox_toggles, "green", ini_read_real("Toggles", "green attack", 0));
    bboxmode = ini_read_real("Keyboard options", "bbox mode", 0);
    
    if (bboxmode)
        ds_map_add(global.bbox_toggles, "mode", "toggle");
    else
        ds_map_add(global.bbox_toggles, "mode", "hold");
    
    ds_map_add(global.bbox_toggles, "active", 1);
    ini_close();
}
else
{
    ini_open("HitboxesSettings.ini");
    ini_write_real("Toggles", "player", 1);
    ini_write_real("Toggles", "interact", 1);
    ini_write_real("Toggles", "special player", 1);
    ini_write_real("Toggles", "transition", 1);
    ini_write_real("Toggles", "solid", 1);
    ini_write_real("Toggles", "cooking show attack", 1);
    ini_write_real("Toggles", "disabled", 1);
    ini_write_real("Toggles", "trigger", 1);
    ini_write_real("Toggles", "inviswall", 1);
    ini_write_real("Toggles", "white attack", 1);
    ini_write_real("Toggles", "frame2 attack", 1);
    ini_write_real("Toggles", "blue attack", 1);
    ini_write_real("Toggles", "orange attack", 1);
    ini_write_real("Toggles", "green attack", 1);
    ini_write_real("Keyboard options", "bbox mode", 1);
    ds_map_add(global.bbox_toggles, "player", 1);
    ds_map_add(global.bbox_toggles, "interact", 1);
    ds_map_add(global.bbox_toggles, "floorint", 1);
    ds_map_add(global.bbox_toggles, "transition", 1);
    ds_map_add(global.bbox_toggles, "solid", 1);
    ds_map_add(global.bbox_toggles, "sattack", 1);
    ds_map_add(global.bbox_toggles, "disabled", 1);
    ds_map_add(global.bbox_toggles, "trigger", 1);
    ds_map_add(global.bbox_toggles, "twall", 1);
    ds_map_add(global.bbox_toggles, "white", 1);
    ds_map_add(global.bbox_toggles, "2fwhite", 1);
    ds_map_add(global.bbox_toggles, "blue", 1);
    ds_map_add(global.bbox_toggles, "orange", 1);
    ds_map_add(global.bbox_toggles, "green", 1);
    ds_map_add(global.bbox_toggles, "mode", "toggle");
    ds_map_add(global.bbox_toggles, "active", 1);
    ini_close();
}

if (!file_exists("HitboxesColors"))
{
    elif = file_text_open_write("HitboxesColors");
    file_text_write_string(elif, "#ffff00");
    file_text_writeln(elif);
    file_text_write_string(elif, "#800080");
    file_text_writeln(elif);
    file_text_write_string(elif, "#00ff00");
    file_text_writeln(elif);
    file_text_write_string(elif, "#00ffff");
    file_text_writeln(elif);
    file_text_write_string(elif, "#0000ff");
    file_text_writeln(elif);
    file_text_write_string(elif, "#000080");
    file_text_writeln(elif);
    file_text_write_string(elif, "#808080");
    file_text_writeln(elif);
    file_text_write_string(elif, "#ff00ff");
    file_text_writeln(elif);
    file_text_write_string(elif, "#008080");
    file_text_writeln(elif);
    file_text_write_string(elif, "#ff0000");
    file_text_writeln(elif);
    file_text_write_string(elif, "#800000");
    file_text_writeln(elif);
    file_text_write_string(elif, "#a500ff");
    file_text_writeln(elif);
    file_text_write_string(elif, "#5aff00");
    file_text_writeln(elif);
    file_text_write_string(elif, "#160dff");
    ds_map_add(global.bbox_colors, "player", "#ffff00");
    ds_map_add(global.bbox_colors, "interact", "#800080");
    ds_map_add(global.bbox_colors, "floorint", "#00ff00");
    ds_map_add(global.bbox_colors, "transition", "#00ffff");
    ds_map_add(global.bbox_colors, "solid", "#0000ff");
    ds_map_add(global.bbox_colors, "sattack", "#000080");
    ds_map_add(global.bbox_colors, "disabled", "#808080");
    ds_map_add(global.bbox_colors, "trigger", "#ff00ff");
    ds_map_add(global.bbox_colors, "twall", "#008080");
    ds_map_add(global.bbox_colors, "white", "#ff0000");
    ds_map_add(global.bbox_colors, "2fwhite", "#800000");
    ds_map_add(global.bbox_colors, "blue", "#a500ff");
    ds_map_add(global.bbox_colors, "orange", "#5aff00");
    ds_map_add(global.bbox_colors, "green", "#160dff");
}
else
{
    elif = file_text_open_read("HitboxesColors");
    ds_map_add(global.bbox_colors, "player", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "interact", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "floorint", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "transition", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "solid", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "sattack", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "disabled", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "trigger", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "twall", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "white", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "2fwhite", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "blue", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "orange", file_text_read_string(elif));
    file_text_readln(elif);
    ds_map_add(global.bbox_colors, "green", file_text_read_string(elif));
    file_text_readln(elif);
}

file_text_close(elif);
