draw_me();

if (cross == 1)
{
    depth = 0;
    draw_sprite(spr_wordsearch, nightmare, 20, 20);
}
else
{
    depth = 100000;
}

if (cross == 1 && cancel == 1)
{
    if (keyboard_multicheck_pressed(0) == 1 || keyboard_multicheck_pressed(1) == 1)
    {
        cancel = 0;
        cross = 0;
        global.interact = 0;
        myinteract = 0;
    }
}

bbox_create("solid", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
bbox_create("interact", bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 0);
