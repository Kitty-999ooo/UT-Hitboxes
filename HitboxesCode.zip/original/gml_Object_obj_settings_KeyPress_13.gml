if (!input)
{
    confirmsettings();
}
else if (input == 1)
{
    comment = '  if (option == 1)
    ohexn = "player";
else if (option == 2)
    ohexn = "interact";
else if (option == 3)
    ohexn = "flooorint";
else if (option == 4)
    ohexn = "transition";
else if (option == 5)
    ohexn = "solid";
else if (option == 6)
    ohexn = "sattack";
else if (option == 7)
    ohexn = "disabled";
else if (option == 8)
    ohexn = "trigger";
else if (option == 9)
    ohexn = "twall";
else if (option == 10)
    ohexn = "white";
else if (option == 11)
    ohexn = "2fwhite";
else if (option == 12)
    ohexn = "blue";
else if (option == 13)
    ohexn = "orange";
else if (option == 14)
    ohexn = "green";';
    ds_map_replace(global.bbox_colors, ohexn, string_replace(hex, "\#", "#"));
    input = 0;
}
