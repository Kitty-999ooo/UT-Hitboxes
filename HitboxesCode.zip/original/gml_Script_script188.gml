if (argument0 == undefined)
    return undefined;

_color = int64(ptr(string_replace(string(argument0), "#", "")));
return ((_color & 16711680) >> 16) | (_color & 65280) | ((_color & 255) << 16);
