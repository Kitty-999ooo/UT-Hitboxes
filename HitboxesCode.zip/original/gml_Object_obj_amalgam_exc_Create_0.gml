image_speed = 0;
yy = y;
con = -1;

if (global.flag[488] == 1)
    instance_destroy();

y = 250;
