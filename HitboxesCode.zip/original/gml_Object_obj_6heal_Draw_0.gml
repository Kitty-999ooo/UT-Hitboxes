draw_self();
xscale = 1.9;
yscale = 1.9;

if (sprite_index == spr_6bandage_big)
{
    xscale = 1;
    yscale = 1;
    image = spr_bandagebox;
}
else if (sprite_index == spr_6pan_egg)
{
    image = spr_eggbox;
}
else if (sprite_index == spr_6gun_flower)
{
    image = spr_flowerbox;
}
else if (sprite_index == spr_6shoe_musicnote)
{
    image = spr_notebox;
}
else if (sprite_index == spr_6hope)
{
    image = spr_hopebox;
}
else if (sprite_index == spr_6thumbsup_small)
{
    image = spr_thumb2box;
}

if (ds_map_find_value(global.bbox_toggles, "active") && ds_map_find_value(global.bbox_toggles, "green"))
    draw_sprite_ext(image, 0, x, y, xscale, yscale, image_angle, HexstringToColor(ds_map_find_value(global.bbox_colors, "green")), 1);
