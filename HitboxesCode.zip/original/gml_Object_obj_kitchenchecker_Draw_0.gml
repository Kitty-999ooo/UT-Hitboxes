draw_sprite_ext(spr_upperlayer, 0, 0, 0, 1, 1, 0, c_white, bgalpha);
draw_sprite_ext(spr_bonepainting, 0, 140, 15, 1, 1, 0, c_white, bgalpha);
bbox_create("trigger", 200, 127, 260, 127, 1, 0);
bbox_create("trigger", 200, 149, 260, 149, 1, 0);
