if (sprite_index == dsprite)
    bbox_create("interact", bbox_left, bbox_top, bbox_right, bbox_bottom + 12, 1, 0);

if (sprite_index == usprite)
    bbox_create("interact", bbox_left, bbox_top - 9, bbox_right, bbox_bottom, 1, 0);

if (sprite_index == rsprite)
    bbox_create("interact", bbox_left, bbox_top, bbox_right + 12, bbox_bottom, 1, 0);

if (sprite_index == lsprite)
    bbox_create("interact", bbox_left - 12, bbox_top, bbox_right, bbox_bottom, 1, 0);

bbox_create("player", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
