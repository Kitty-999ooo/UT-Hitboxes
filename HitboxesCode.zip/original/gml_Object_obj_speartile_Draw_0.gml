draw_self();

if (active)
{
    if (image_alpha == 1 && ready)
        bbox_create("white", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
    else
        bbox_create("disabled", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
}
