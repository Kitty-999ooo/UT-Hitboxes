noofoptions = 15;
menu = 0;
input = 0;
hex = "\#";
