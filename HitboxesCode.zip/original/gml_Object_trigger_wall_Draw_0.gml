bbox_create("twall", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);

if (room == room_ruins3 && global.plot <= 3)
{
    bbox_create("trigger", 160, -10, 160, 250, 1, 0);
    bbox_create("trigger", -10, 188, 740, 188, 1, 0);
}
