draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, image_angle, image_blend, image_alpha);

if ((shake == 0 && global.attackt) || (shakeboy == 1 && global.attackt))
    draw_sprite_ext(spr_gunbox, image_index, x, y, image_xscale, image_yscale, image_angle, HexstringToColor(global.whitecolor), image_alpha);
else if (global.disabledt)
    draw_sprite_ext(spr_gunbox, image_index, x, y, image_xscale, image_yscale, image_angle, HexstringToColor(global.disabledcolor), image_alpha);
