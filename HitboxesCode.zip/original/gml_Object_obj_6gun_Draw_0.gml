draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, image_angle, image_blend, image_alpha);

if (ds_map_find_value(global.bbox_toggles, "active"))
{
    if ((shake == 0 && ds_map_find_value(global.bbox_toggles, "white")) || (shakeboy == 1 && ds_map_find_value(global.bbox_toggles, "white")))
        draw_sprite_ext(spr_gunbox, image_index, x, y, image_xscale, image_yscale, image_angle, HexstringToColor(ds_map_find_value(global.bbox_colors, "white")), image_alpha);
    else if (ds_map_find_value(global.bbox_toggles, "disabled"))
        draw_sprite_ext(spr_gunbox, image_index, x, y, image_xscale, image_yscale, image_angle, HexstringToColor(ds_map_find_value(global.bbox_colors, "disabled")), image_alpha);
}
