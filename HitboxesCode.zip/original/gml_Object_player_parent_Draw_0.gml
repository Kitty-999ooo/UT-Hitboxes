draw_self();

if (!(object_index == obj_dateheart || instance_exists(obj_amalgambul_parent) || instance_exists(obj_sansb)))
{
    bbox_create("player", x + 2, y, x + 3, y, 0, 0);
    bbox_create("player", x + 12, y, x + 13, y, 0, 0);
    bbox_create("player", x + 10, y + 1, x + 14, y + 1, 0, 0);
    bbox_create("player", x + 1, y + 1, x + 5, y + 1, 0, 0);
    bbox_create("player", x, y + 2, x, y + 9, 0, 0);
    bbox_create("player", x + 15, y + 2, x + 15, y + 9, 0, 0);
    bbox_create("player", x + 5, y + 2, x + 6, y + 2, 0, 0);
    bbox_create("player", x + 9, y + 2, x + 10, y + 2, 0, 0);
    bbox_create("player", x + 6, y + 2, x + 6, y + 4, 0, 0);
    bbox_create("player", x + 9, y + 2, x + 9, y + 4, 0, 0);
    bbox_create("player", x + 6, y + 4, x + 9, y + 4, 0, 0);
    bbox_create("player", x + 0, y + 9, x + 1, y + 9, 0, 0);
    bbox_create("player", x + 14, y + 9, x + 15, y + 9, 0, 0);
    bbox_create("player", x + 2, y + 9, x + 2, y + 11, 0, 0);
    bbox_create("player", x + 13, y + 9, x + 13, y + 11, 0, 0);
    bbox_create("player", x + 2, y + 11, x + 3, y + 11, 0, 0);
    bbox_create("player", x + 13, y + 11, x + 12, y + 11, 0, 0);
    bbox_create("player", x + 11, y + 11, x + 11, y + 12, 0, 0);
    bbox_create("player", x + 3, y + 11, x + 3, y + 12, 0, 0);
    bbox_create("player", x + 4, y + 13, x + 6, y + 13, 0, 0);
    bbox_create("player", x + 10, y + 13, x + 11, y + 13, 0, 0);
    bbox_create("player", x + 9, y + 13, x + 9, y + 15, 0, 0);
    bbox_create("player", x + 6, y + 14, x + 6, y + 15, 0, 0);
    bbox_create("player", x + 6, y + 15, x + 9, y + 15, 0, 0);
}

if (object_index == obj_dateheart || instance_exists(obj_amalgambul_parent) || instance_exists(obj_sansb))
    bbox_create("player", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);

if (instance_exists(obj_sansb))
    bbox_create("trigger", global.idealborder[0] + 4, bbox_top, global.idealborder[0] + 4, bbox_bottom, 1, 0, "line", 2);
