draw_self();

if (instance_exists(obj_sans_room))
{
    bbox_create("solid", obj_sans_room.bbox_left, obj_sans_room.bbox_top, obj_sans_room.bbox_right, obj_sans_room.bbox_bottom, 1, 0);
    bbox_create("interact", obj_sans_room.bbox_left - 4, obj_sans_room.bbox_top - 4, obj_sans_room.bbox_right + 3, obj_sans_room.bbox_bottom + 2, 1, 0);
}

if (instance_exists(obj_sans_sentry2))
{
    bbox_create("solid", obj_sans_sentry2.bbox_left, obj_sans_sentry2.bbox_top, obj_sans_sentry2.bbox_right, obj_sans_sentry2.bbox_bottom, 1, 0);
    bbox_create("interact", obj_sans_sentry2.bbox_left - 4, obj_sans_sentry2.bbox_top - 4, obj_sans_sentry2.bbox_right + 3, obj_sans_sentry2.bbox_bottom + 2, 1, 0);
}
