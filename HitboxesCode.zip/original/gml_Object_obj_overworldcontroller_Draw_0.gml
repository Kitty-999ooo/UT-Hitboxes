buffer += 1;
comment = "weapon/armor names & LV/XP values";
weaponname = " ";
armorname = " ";

if (global.weapon == 3)
    weaponname = "Stick";

if (global.weapon == 13)
    weaponname = "Toy Knife";

if (global.weapon == 14)
    weaponname = "Tough Glove";

if (global.weapon == 25)
    weaponname = "Ballet Shoes";

if (global.weapon == 45)
    weaponname = "Torn Notebook";

if (global.weapon == 47)
    weaponname = "Burnt Pan";

if (global.weapon == 49)
    weaponname = "Empty Gun";

if (global.weapon == 51)
    weaponname = "Worn Dagger";

if (global.weapon == 52)
    weaponname = "Real Knife";

if (global.armor == 4)
    armorname = "Bandage";

if (global.armor == 12)
    armorname = "Faded Ribbon";

if (global.armor == 15)
    armorname = "Manly Bandanna";

if (global.armor == 24)
    armorname = "Old Tutu";

if (global.armor == 44)
    armorname = "Clouded Glasses";

if (global.armor == 46)
    armorname = "Stained Apron";

if (global.armor == 48)
    armorname = "Cowboy Hat";

if (global.armor == 50)
    armorname = "Heart Locket";

if (global.armor == 53)
    armorname = "The Locket";

if (global.armor == 64)
    armorname = "Temmie Armor";

if (global.lv == 1)
    nextlevel = 10 - global.xp;

if (global.lv == 2)
    nextlevel = 30 - global.xp;

if (global.lv == 3)
    nextlevel = 70 - global.xp;

if (global.lv == 4)
    nextlevel = 120 - global.xp;

if (global.lv == 5)
    nextlevel = 200 - global.xp;

if (global.lv == 6)
    nextlevel = 300 - global.xp;

if (global.lv == 7)
    nextlevel = 500 - global.xp;

if (global.lv == 8)
    nextlevel = 800 - global.xp;

if (global.lv == 9)
    nextlevel = 1200 - global.xp;

if (global.lv == 10)
    nextlevel = 1700 - global.xp;

if (global.lv == 11)
    nextlevel = 2500 - global.xp;

if (global.lv == 12)
    nextlevel = 3500 - global.xp;

if (global.lv == 13)
    nextlevel = 5000 - global.xp;

if (global.lv == 14)
    nextlevel = 7000 - global.xp;

if (global.lv == 15)
    nextlevel = 10000 - global.xp;

if (global.lv == 16)
    nextlevel = 15000 - global.xp;

if (global.lv == 17)
    nextlevel = 25000 - global.xp;

if (global.lv == 18)
    nextlevel = 50000 - global.xp;

if (global.lv == 19)
    nextlevel = 99999 - global.xp;

if (global.lv >= 20)
    nextlevel = 0;

comment = "menu code";

if (global.interact == 5)
{
    currentmenu = global.menuno;
    
    if ((global.menuno < 6 || global.menuno >= 10) && global.menuno < 99)
        currentspot = global.menucoord[global.menuno];
    
    xx = view_xview[view_current];
    yy = view_yview[view_current] + 10;
    moveyy = yy;
    
    if (obj_mainchara.y > (yy + 120))
        moveyy += 135;
    
    if (global.menuno != 4 && global.menuno < 10)
    {
        draw_set_color(c_white);
        draw_rectangle(16 + xx, 16 + moveyy, 86 + xx, 70 + moveyy, false);
        draw_rectangle(16 + xx, 74 + yy, 86 + xx, 147 + yy, false);
        
        if (global.menuno == 1 || global.menuno == 5 || global.menuno == 6)
            draw_rectangle(94 + xx, 16 + yy, 266 + xx, 196 + yy, false);
        
        if (global.menuno == 2)
            draw_rectangle(94 + xx, 16 + yy, 266 + xx, 224 + yy, false);
        
        if (global.menuno == 3)
            draw_rectangle(94 + xx, 16 + yy, 266 + xx, 150 + yy, false);
        
        if (global.menuno == 7)
            draw_rectangle(94 + xx, 16 + yy, 266 + xx, 216 + yy, false);
        
        draw_set_color(c_black);
        draw_rectangle(19 + xx, 19 + moveyy, 83 + xx, 67 + moveyy, false);
        draw_rectangle(19 + xx, 77 + yy, 83 + xx, 144 + yy, false);
        
        if (global.menuno == 1 || global.menuno == 5 || global.menuno == 6)
            draw_rectangle(97 + xx, 19 + yy, 263 + xx, 193 + yy, false);
        
        if (global.menuno == 2)
            draw_rectangle(97 + xx, 19 + yy, 263 + xx, 221 + yy, false);
        
        if (global.menuno == 3)
            draw_rectangle(97 + xx, 19 + yy, 263 + xx, 147 + yy, false);
        
        if (global.menuno == 7)
            draw_rectangle(97 + xx, 19 + yy, 263 + xx, 213 + yy, false);
        
        draw_set_color(c_white);
        draw_set_font(fnt_small);
        draw_text(23 + xx, 49 + moveyy, "HP  " + string(global.hp) + "/" + string(global.maxhp));
        draw_text(23 + xx, 40 + moveyy, "LV  " + string(global.lv));
        draw_text(23 + xx, 58 + moveyy, "G   " + string(global.gold));
        draw_set_font(fnt_maintext);
        draw_text(23 + xx, 20 + moveyy, global.charname);
        
        if (global.menuchoice[0] == 1)
            draw_text(42 + xx, 84 + yy, "ITEM");
        
        if (global.menuchoice[1] == 1)
            draw_text(42 + xx, 102 + yy, "STAT");
        
        if (global.menuchoice[2] == 1)
            draw_text(42 + xx, 120 + yy, "CELL");
        
        if (global.menuno == 1 || global.menuno == 5)
        {
            for (i = 0; i < 8; i += 1)
                draw_text(116 + xx, 30 + yy + (i * 16), global.itemname[i]);
            
            draw_text(116 + xx, 170 + yy, "USE");
            draw_text(116 + xx + 48, 170 + yy, "INFO");
            draw_text(116 + xx + 105, 170 + yy, "DROP");
        }
    }
    
    if (global.menuno == 3)
    {
        for (i = 0; i < 7; i += 1)
            draw_text(116 + xx, 30 + yy + (i * 16), global.phonename[i]);
    }
    
    if (global.menuno == 6)
    {
        scr_itemname();
        
        for (i = 0; i < 8; i += 1)
            draw_text(116 + xx, 30 + yy + (i * 16), global.itemname[i]);
    }
    
    if (global.menuno == 7)
    {
        scr_storagename(300);
        
        for (i = 0; i < 10; i += 1)
            draw_text(116 + xx, 30 + yy + (i * 16), global.itemname[i]);
    }
    
    if (global.menuno == 2)
    {
        draw_text(108 + xx, 32 + yy, '"' + global.charname + '"');
        draw_text(108 + xx, 62 + yy, "LV  " + string(global.lv));
        draw_text(108 + xx, 78 + yy, "HP  " + string(global.hp) + " / " + string(global.maxhp));
        draw_text(108 + xx, 110 + yy, "AT  " + string(global.at - 10) + " (" + string(global.wstrength) + ")");
        draw_text(108 + xx, 126 + yy, "DF  " + string(global.df - 10) + " (" + string(global.adef) + ")");
        draw_text(108 + xx, 156 + yy, "WEAPON: " + weaponname);
        draw_text(108 + xx, 172 + yy, "ARMOR: " + armorname);
        draw_text(108 + xx, 192 + yy, "GOLD: " + string(global.gold));
        
        if (global.kills > 20)
            draw_text(192 + xx, 192 + yy, "KILLS: " + string(global.kills));
        
        if (string_length(global.charname) >= 7)
            draw_text(192 + xx, 32 + yy, "Easy to#change,#huh?");
        
        draw_text(192 + xx, 110 + yy, "EXP: " + string(global.xp));
        draw_text(192 + xx, 126 + yy, "NEXT: " + string(nextlevel));
    }
    
    if (global.menuno == 4)
    {
        iniread = ini_open("undertale.ini");
        name = ini_read_string("General", "Name", "EMPTY");
        love = ini_read_real("General", "Love", 0);
        time = ini_read_real("General", "Time", 1);
        kills = ini_read_real("General", "Kills", 0);
        roome = ini_read_real("General", "Room", 0);
        ini_close();
        draw_set_font(fnt_maintext);
        draw_set_color(c_white);
        draw_rectangle(54 + xx, 49 + yy, 265 + xx, 135 + yy, false);
        draw_set_color(c_black);
        draw_rectangle(57 + xx, 52 + yy, 262 + xx, 132 + yy, false);
        draw_set_color(c_white);
        
        if (global.menucoord[4] == 2)
            draw_set_color(c_yellow);
        
        minutes = floor(time / 1800);
        seconds = round(((time / 1800) - minutes) * 60);
        
        if (seconds == 60)
            seconds = 59;
        
        if (seconds < 10)
            seconds = "0" + string(seconds);
        
        script_execute(scr_roomname, roome);
        draw_text(70 + xx, 60 + yy, name);
        draw_text(140 + xx, 60 + yy, "LV " + string(love));
        draw_text(210 + xx, 60 + yy, string(minutes) + ":" + string(seconds));
        draw_text(70 + xx, 80 + yy, roomname);
        
        if (global.menucoord[4] == 0)
            draw_sprite(spr_heartsmall, 0, xx + 71, yy + 113);
        
        if (global.menucoord[4] == 1)
            draw_sprite(spr_heartsmall, 0, xx + 161, yy + 113);
        
        if (global.menucoord[4] < 2)
        {
            draw_text(xx + 85, yy + 110, "Save");
            draw_text(xx + 175, yy + 110, "Return");
        }
        else
        {
            draw_text(xx + 85, yy + 110, "File saved.");
            
            if (keyboard_multicheck_pressed(13))
            {
                global.menuno = -1;
                global.interact = 0;
                global.menucoord[4] = 0;
                keyboard_clear(vk_enter);
                keyboard_clear(ord("Z"));
            }
        }
        
        if (keyboard_check_pressed(vk_left) || keyboard_check_pressed(vk_right))
        {
            if (global.menucoord[4] < 2)
            {
                if (global.menucoord[4] == 1)
                    global.menucoord[4] = 0;
                else
                    global.menucoord[4] = 1;
                
                keyboard_clear(vk_left);
                keyboard_clear(vk_right);
            }
        }
        
        if (keyboard_multicheck_pressed(13) && global.menucoord[4] == 0)
        {
            snd_play(snd_save);
            script_execute(scr_save);
            global.menucoord[4] = 2;
            keyboard_clear(vk_enter);
            keyboard_clear(ord("Z"));
        }
        
        if (keyboard_multicheck_pressed(13) && global.menucoord[4] == 1)
        {
            global.menuno = -1;
            global.interact = 0;
            global.menucoord[4] = 0;
            keyboard_clear(vk_enter);
            keyboard_clear(ord("Z"));
        }
        
        if (keyboard_multicheck_pressed(16))
        {
            global.menuno = -1;
            global.interact = 0;
            global.menucoord[4] = 0;
            keyboard_clear(vk_shift);
            keyboard_clear(ord("X"));
        }
    }
    
    if (global.menuno == 0)
        draw_sprite(spr_heartsmall, 0, 28 + xx, 88 + yy + (18 * global.menucoord[0]));
    
    if (global.menuno == 1)
        draw_sprite(spr_heartsmall, 0, 104 + xx, 34 + yy + (16 * global.menucoord[1]));
    
    if (global.menuno == 3)
        draw_sprite(spr_heartsmall, 0, 104 + xx, 34 + yy + (16 * global.menucoord[3]));
    
    if (global.menuno == 6)
        draw_sprite(spr_heartsmall, 0, 104 + xx, 34 + yy + (16 * global.menucoord[6]));
    
    if (global.menuno == 7)
        draw_sprite(spr_heartsmall, 0, 104 + xx, 34 + yy + (16 * global.menucoord[7]));
    
    if (global.menuno == 5)
    {
        if (global.menucoord[5] == 0)
            draw_sprite(spr_heartsmall, 0, 104 + xx + (45 * global.menucoord[5]), 174 + yy);
        
        if (global.menucoord[5] == 1)
            draw_sprite(spr_heartsmall, 0, 104 + xx + ((45 * global.menucoord[5]) + 3), 174 + yy);
        
        if (global.menucoord[5] == 2)
            draw_sprite(spr_heartsmall, 0, 104 + xx + ((45 * global.menucoord[5]) + 15), 174 + yy);
    }
    
    comment = "Custom menus (text and hearts)";
    
    if (global.debugMenuFont == 0)
        menufont = 2;
    else if (global.debugMenuFont == 1)
        menufont = 8;
    else if (global.debugMenuFont == 2)
        menufont = 9;
    
    draw_set_font(menufont);
    
    if (global.textInputActive)
    {
        if (keyboard_check(vk_control) && keyboard_check_pressed(vk_backspace))
        {
            snd_play(snd_swallow);
            global.textInputActive = 0;
        }
    }
    
    isCustomMenu = 0;
    
    if (global.menuno >= 10 && global.menuno < 99)
    {
        isCustomMenu = 1;
        draw_set_halign(fa_right);
        upTime = "Session time: ";
        timer = get_timer();
        minutes = floor(timer / 60000000);
        seconds = floor((timer - (minutes * 60000000)) / 1000000);
        upTime += string(minutes);
        
        if (seconds < 10)
            upTime += ":0";
        else
            upTime += ":";
        
        upTime += string(seconds);
        draw_set_color(c_black);
        draw_text_transformed(297.5 + xx, 219.7 + yy, upTime, 0.5, 0.5, 0);
        draw_set_color(c_white);
        draw_text_transformed(297 + xx, 219 + yy, upTime, 0.5, 0.5, 0);
        draw_set_halign(fa_left);
        draw_set_color(c_white);
        draw_rectangle(22 + xx, 16 + yy, 296 + xx, 216 + yy, false);
        draw_set_color(c_black);
        draw_rectangle(25 + xx, 19 + yy, 293 + xx, 213 + yy, false);
        drawMenuOption(10, 0, 42 + xx, 24 + yy, "Main");
        drawMenuOption(10, 1, 88 + xx, 24 + yy, "Timer");
        drawMenuOption(10, 2, 142 + xx, 24 + yy, "Stats");
        drawMenuOption(10, 3, 196 + xx, 24 + yy, "Items");
        drawMenuOption(10, 4, 248 + xx, 24 + yy, "Misc");
        
        if ((global.menucoord[10] == 0 || global.menuno == 11) && global.menuno < 12)
        {
            drawSplashText = 1;
            offset = 0;
            offsetY = 0;
            
            if (global.modUpToDate == 0)
            {
                drawMenuOption(11, 0, 42 + xx, 44 + yy, "Download New Version: " + global.latestVersion);
                offset = 1;
                offsetY = 18;
            }
            
            if (global.debugTemp)
                text = "Debug: ON";
            else
                text = "Debug: OFF";
            
            drawMenuOption(11, 0 + offset, 42 + xx, 44 + yy + offsetY, text);
            drawMenuInfoText(11, 0 + offset, 28 + xx, 196 + yy, "* Hold Ctrl to edit hotkeys.");
            
            if (global.savestatesTemp == 2)
                text = "Savestates: ON";
            else if (global.savestatesTemp == 1)
                text = "Savestates: Load-only";
            else if (global.savestatesTemp == 0)
                text = "Savestates: OFF";
            
            drawMenuOption(11, 1 + offset, 42 + xx, 58 + yy + offsetY, text);
            drawMenuInfoText(11, 1 + offset, 28 + xx, 196 + yy, "* Hold Ctrl to edit hotkeys.");
            
            if (global.musicEnabled)
                text = "Music: ON";
            else
                text = "Music: OFF";
            
            drawMenuOption(11, 2 + offset, 42 + xx, 72 + yy + offsetY, text);
            drawMenuOption(11, 3 + offset, 42 + xx, 90 + yy + offsetY, "Practice Weapons...");
            drawMenuOption(11, 4 + offset, 42 + xx, 104 + yy + offsetY, "Practice MDS");
            drawMenuInfoText(11, 4 + offset, 28 + xx, 196 + yy, "* Hold Ctrl to edit flags.");
            drawMenuOption(11, 5 + offset, 42 + xx, 122 + yy + offsetY, "Teleport to room");
            drawMenuOption(11, 6 + offset, 42 + xx, 136 + yy + offsetY, "Start battle");
            drawMenuOption(11, 7 + offset, 42 + xx, 150 + yy + offsetY, "Fix battle box");
            drawMenuInfoText(11, 7 + offset, 28 + xx, 196 + yy, "* Sets global.border and global.mercy to 0.");
            draw_set_color(c_gray);
            
            if (global.menuno != 11)
                draw_set_color(merge_color(c_yellow, c_gray, 0.5));
            else
                draw_set_color(c_yellow);
            
            if (drawSplashText)
                draw_text(28 + xx, 196 + yy, flavorText[flavorTextNum]);
        }
        
        if (global.menucoord[10] == 2 || global.menuno == 12)
        {
            if (global.menuno == 12)
                draw_set_color(c_white);
            else
                draw_set_color(c_gray);
            
            draw_text(36 + xx, 44 + yy, '"' + global.charname + '"');
            draw_text(36 + xx, 62 + yy, "LV  " + string(global.lv));
            draw_text(36 + xx, 78 + yy, "HP  " + string(global.hp) + " / " + string(global.maxhp));
            draw_text(36 + xx, 96 + yy, "AT  " + string(global.at - 10) + " (" + string(global.wstrength) + ")");
            draw_text(36 + xx, 110 + yy, "DF  " + string(global.df - 10) + " (" + string(global.adef) + ")");
            draw_text(36 + xx, 128 + yy, "WEAPON: " + weaponname);
            draw_text(36 + xx, 142 + yy, "ARMOR: " + armorname);
            draw_text(36 + xx, 160 + yy, "GOLD: " + string(global.gold));
            draw_text(106 + xx, 96 + yy, "EXP: " + string(global.xp));
            draw_text(106 + xx, 110 + yy, "NEXT: " + string(nextlevel));
            draw_text_transformed(36 + xx, 190 + yy, "Note: UNDERTALE subtracts 10 from the AT and DF values displayed.#For example: An AT value of 10 is displayed as 0.", 0.5, 0.5, 0);
            drawMenuOption(12, 0, 184 + xx, 44 + yy, "Change Name");
            drawMenuOption(12, 1, 184 + xx, 58 + yy, "Change LV");
            drawMenuOption(12, 2, 184 + xx, 72 + yy, "Change EXP");
            drawMenuOption(12, 3, 184 + xx, 86 + yy, "Change HP");
            drawMenuOption(12, 4, 184 + xx, 100 + yy, "Change Max HP");
            drawMenuOption(12, 5, 184 + xx, 114 + yy, "Change AT");
            drawMenuOption(12, 6, 184 + xx, 128 + yy, "Change DF");
            drawMenuOption(12, 7, 184 + xx, 142 + yy, "Change WEAPON");
            drawMenuOption(12, 8, 184 + xx, 156 + yy, "Change ARMOR");
            drawMenuOption(12, 9, 184 + xx, 170 + yy, "Change GOLD");
        }
        
        if (global.menucoord[10] == 3 || global.menuno == 13 || global.menuno == 15 || global.menuno == 16)
        {
            drawMenuOption(13, 0, 60 + xx, 40 + yy, "Normal");
            drawMenuOption(13, 1, 170 + xx, 40 + yy, "Consumables");
        }
        
        if ((global.menucoord[10] == 4 || global.menuno == 14) && global.menuno < 15)
        {
            drawMenuOption(14, 0, 42 + xx, 44 + yy, "Change file0 flag");
            drawMenuOption(14, 1, 42 + xx, 58 + yy, "Change undertale.ini flag");
            drawMenuOption(14, 2, 42 + xx, 74 + yy, "Change plot");
            drawMenuOption(14, 3, 42 + xx, 88 + yy, "Change Fun value");
            
            if (global.monstertaleSkippable)
                text = "Monstertale Always Skippable: ON";
            else
                text = "Monstertale Always Skippable: OFF";
            
            drawMenuOption(14, 4, 42 + xx, 104 + yy, text);
            drawMenuInfoText(14, 4, 28 + xx, 196 + yy, "* ENABLING THIS IS ILLEGAL FOR ILS!", 255);
            
            if (global.fixedblcon > -1)
                text = "Fixed blcon RNG: 15+" + string(global.fixedblcon) + "f";
            else if (global.fixedblcon == -1)
                text = "Fixed blcon RNG: OFF";
            
            drawMenuOption(14, 5, 42 + xx, 118 + yy, text);
            drawMenuInfoText(14, 5, 28 + xx, 196 + yy, "* ENABLING THIS IS ILLEGAL FOR ILS!", 255);
            drawMenuOption(14, 6, 42 + xx, 134 + yy, "Menu Options...");
            draw_set_color(c_gray);
            draw_text(28 + xx, 150 + yy, "UNDERTALE Practice Mod + hitboxes mod");
            draw_text_transformed(28 + xx, 164 + yy, "Developed by Winter Storm, Indyindeed, willyjwillyj, & OceanBagel #Full credits in README.TXT     (the hitboxes mod was an addon to the practice mod, #and will not be in any future versions of the practice mod)", 0.5, 0.5, 0);
            
            switch (global.modUpToDate)
            {
                case -2:
                    text = "";
                    break;
                
                case -1:
                    text = "Couldn't check version. Is GitHub down?";
                    break;
                
                case 0:
                    text = "New version available: " + global.latestVersion + ".";
                    break;
                
                case 1:
                    text = "Mod is up to date.";
                    break;
            }
            
            draw_text(28 + xx, 185 + yy, text);
        }
        
        if ((global.menucoord[13] == 0 && global.menuno == 13) || global.menuno == 15)
        {
            drawMenuOption(15, 0, 42 + xx, 56 + yy, "Stick");
            drawMenuOption(15, 1, 42 + xx, 70 + yy, "Toy Knife");
            drawMenuOption(15, 2, 42 + xx, 84 + yy, "TuffGlove");
            drawMenuOption(15, 3, 42 + xx, 98 + yy, "BallShoes");
            drawMenuOption(15, 4, 42 + xx, 112 + yy, "TornNotbo");
            drawMenuOption(15, 5, 42 + xx, 126 + yy, "Burnt Pan");
            drawMenuOption(15, 6, 42 + xx, 140 + yy, "Empty Gun");
            drawMenuOption(15, 7, 42 + xx, 154 + yy, "WornDG");
            drawMenuOption(15, 8, 42 + xx, 168 + yy, "RealKnife");
            drawMenuOption(15, 9, 126 + xx, 56 + yy, "Bandage");
            drawMenuOption(15, 10, 126 + xx, 70 + yy, "Ribbon");
            drawMenuOption(15, 11, 126 + xx, 84 + yy, "Mandanna");
            drawMenuOption(15, 12, 126 + xx, 98 + yy, "Old Tutu");
            drawMenuOption(15, 13, 126 + xx, 112 + yy, "ClodGlass");
            drawMenuOption(15, 14, 126 + xx, 126 + yy, "StainApro");
            drawMenuOption(15, 15, 126 + xx, 140 + yy, "CowboyHat");
            drawMenuOption(15, 16, 126 + xx, 154 + yy, "<--Locket");
            drawMenuOption(15, 17, 126 + xx, 168 + yy, "TheLocket");
            drawMenuOption(15, 18, 126 + xx, 182 + yy, "temy armor");
            drawMenuOption(15, 19, 210 + xx, 56 + yy, "PunchCard");
            drawMenuOption(15, 20, 210 + xx, 70 + yy, "Dog");
            drawMenuOption(15, 21, 210 + xx, 84 + yy, "Dog Salad");
            drawMenuOption(15, 22, 210 + xx, 98 + yy, "DogResidu");
            drawMenuOption(15, 23, 210 + xx, 112 + yy, "UndynLetr");
            drawMenuOption(15, 24, 210 + xx, 126 + yy, "UndyneLtrX");
            drawMenuOption(15, 25, 210 + xx, 140 + yy, "MystryKey");
        }
        
        if ((global.menucoord[13] == 1 && global.menuno == 13) || global.menuno == 16)
        {
            drawMenuOption(16, 0, 42 + xx, 56 + yy, "MnstrCndy");
            drawMenuOption(16, 1, 42 + xx, 70 + yy, "CroqtRoll");
            drawMenuOption(16, 2, 42 + xx, 84 + yy, "RockCandy");
            drawMenuOption(16, 3, 42 + xx, 98 + yy, "PunkRings");
            drawMenuOption(16, 4, 42 + xx, 112 + yy, "SpidrDont");
            drawMenuOption(16, 5, 42 + xx, 126 + yy, "StocOnoin");
            drawMenuOption(16, 6, 42 + xx, 140 + yy, "GhostFrut");
            drawMenuOption(16, 7, 42 + xx, 154 + yy, "SpidrCidr");
            drawMenuOption(16, 8, 42 + xx, 168 + yy, "ButtsPie");
            drawMenuOption(16, 9, 42 + xx, 182 + yy, "SnowPiece");
            drawMenuOption(16, 10, 42 + xx, 196 + yy, "NiceCream");
            drawMenuOption(16, 11, 126 + xx, 56 + yy, "PDIceCram");
            drawMenuOption(16, 12, 126 + xx, 70 + yy, "Bisicle");
            drawMenuOption(16, 13, 126 + xx, 84 + yy, "CinnaBun");
            drawMenuOption(16, 14, 126 + xx, 98 + yy, "TemFlakes");
            drawMenuOption(16, 15, 126 + xx, 112 + yy, "Ab Quiche");
            drawMenuOption(16, 16, 126 + xx, 126 + yy, "DogSalad");
            drawMenuOption(16, 17, 126 + xx, 140 + yy, "AstroFood");
            drawMenuOption(16, 18, 126 + xx, 154 + yy, "InstaNood");
            drawMenuOption(16, 19, 126 + xx, 168 + yy, "CrabApple");
            drawMenuOption(16, 20, 126 + xx, 182 + yy, "Hot Dog");
            drawMenuOption(16, 21, 126 + xx, 196 + yy, "Hot Cat");
            drawMenuOption(16, 22, 210 + xx, 56 + yy, "GlamBurg");
            drawMenuOption(16, 23, 210 + xx, 70 + yy, "Sea Tea");
            drawMenuOption(16, 24, 210 + xx, 84 + yy, "Starfait");
            drawMenuOption(16, 25, 210 + xx, 98 + yy, "Leg,Hero");
            drawMenuOption(16, 26, 210 + xx, 112 + yy, "BadMemory");
            drawMenuOption(16, 27, 210 + xx, 126 + yy, "LastDream");
            drawMenuOption(16, 28, 210 + xx, 140 + yy, "PT Chisps");
            drawMenuOption(16, 29, 210 + xx, 154 + yy, "Junk Food");
            drawMenuOption(16, 30, 210 + xx, 168 + yy, "FaceSteak");
            drawMenuOption(16, 31, 210 + xx, 182 + yy, "HushPupe");
            drawMenuOption(16, 32, 210 + xx, 196 + yy, "Snail Pie");
        }
        
        if (global.menuno == 17)
        {
        }
        
        if (global.menuno == 18)
        {
            draw_text(42 + xx, 44 + yy, "Practice Weapons...");
            drawMenuOption(18, 0, 42 + xx, 58 + yy, "Start Battle");
            
            if (weaponPracticeBoss == 0)
                bossname = "Asgore";
            else if (weaponPracticeBoss == 1)
                bossname = "Mettaton";
            else if (weaponPracticeBoss == 2)
                bossname = "Undyne the Undying";
            else if (weaponPracticeBoss == 3)
                bossname = "Training Dummy";
            
            drawMenuOption(18, 1, 42 + xx, 72 + yy, "Boss: " + bossname);
            
            if (weaponPracticeWeapon == 0)
                weaponname = "Burnt Pan";
            else if (weaponPracticeWeapon == 1)
                weaponname = "Ballet Shoes";
            else if (weaponPracticeWeapon == 2)
                weaponname = "Empty Gun";
            else if (weaponPracticeWeapon == 3)
                weaponname = "Torn Notebook";
            
            drawMenuOption(18, 2, 42 + xx, 86 + yy, "Weapon: " + weaponname);
            
            if (weaponPracticeBoss != 3)
            {
                drawMenuOption(18, 3, 42 + xx, 100 + yy, "LV: " + string(weaponPracticeLV));
                
                if (weaponPracticeAttacks)
                    text = "Attacks: ON";
                else
                    text = "Attacks: OFF";
                
                drawMenuOption(18, 4, 42 + xx, 114 + yy, text);
                
                if (weaponPracticeBoss == 2)
                    text = "Truly Undying: ";
                else
                    text = "Boss is Invincible: ";
                
                if (weaponPracticeBossInv)
                    text += "ON";
                else
                    text += "OFF";
                
                drawMenuOption(18, 5, 42 + xx, 128 + yy, text);
                
                if (weaponPracticePlayerInv)
                    text = "Player is Invincible: ON";
                else
                    text = "Player is Invincible: OFF";
                
                drawMenuOption(18, 6, 42 + xx, 142 + yy, text);
                
                if (weaponPracticeBoss != 2)
                    drawMenuOption(18, 7, 42 + xx, 156 + yy, "Turn Goal: " + string(weaponPracticeTurnGoal));
                
                if (weaponPracticeBoss == 1)
                {
                    if (weaponPracticeMttRatings)
                        text = "Ratings: ON";
                    else
                        text = "Ratings: OFF";
                    
                    drawMenuOption(18, 8, 42 + xx, 170 + yy, text);
                    
                    if (global.menucoord[18] == 8)
                    {
                        draw_set_color(c_gray);
                        draw_text(42 + xx, 196 + yy, "Note: This makes the stats look weird.");
                    }
                }
            }
        }
        
        if ((global.menucoord[10] == 1 || global.menuno == 19) && global.menuno < 20)
        {
            if (obj_time.timerEnable)
                text = "Hide timer";
            else
                text = "Show timer";
            
            drawMenuOption(19, 0, 42 + xx, 44 + yy, text);
            drawMenuOption(19, 1, 42 + xx, 60 + yy, "Presets...");
            drawMenuOption(19, 2, 42 + xx, 76 + yy, "Edit splits...");
            drawMenuOption(19, 3, 42 + xx, 90 + yy, "Edit style...");
            drawMenuOption(19, 4, 42 + xx, 104 + yy, "Edit hotkeys...");
            draw_set_color(c_gray);
            draw_text(42 + xx, 120 + yy, "Primary Timer:");
            
            if (obj_time.primaryTiming == 0)
                text = "Run";
            else if (obj_time.primaryTiming == 1)
                text = "Segment";
            
            drawMenuOption(19, 5, 42 + xx, 134 + yy, "Timing: " + text);
            
            if (obj_time.primaryUpdate == 0)
                text = "Constantly";
            else if (obj_time.primaryUpdate == 1)
                text = "On room change";
            
            drawMenuOption(19, 6, 42 + xx, 148 + yy, "Update: " + text);
            draw_set_color(c_gray);
            draw_text(42 + xx, 164 + yy, "Secondary Timer:");
            
            if (obj_time.secondaryTiming == 0)
                text = "Run";
            else if (obj_time.secondaryTiming == 1)
                text = "Segment";
            
            drawMenuOption(19, 7, 42 + xx, 178 + yy, "Timing: " + text);
            
            if (obj_time.secondaryUpdate == 0)
                text = "Constantly";
            else if (obj_time.secondaryUpdate == 1)
                text = "On room change";
            
            drawMenuOption(19, 8, 42 + xx, 192 + yy, "Update: " + text);
        }
        
        if (global.menuno == 20)
        {
            draw_set_color(c_gray);
            draw_text(42 + xx, 44 + yy, "Menu Options...");
            
            if (global.checkUpdate)
                text = "ON";
            else
                text = "OFF";
            
            drawMenuOption(20, 0, 42 + xx, 58 + yy, "Automatically check for updates: " + text);
            
            if (!obj_time.versionCheck && global.modUpToDate == -2)
            {
                draw_set_color(c_gray);
                draw_text(42 + xx, 74 + yy, "Checking...");
            }
            else
            {
                drawMenuOption(20, 1, 42 + xx, 72 + yy, "Check for update");
            }
            
            drawMenuOption(20, 2, 42 + xx, 88 + yy, "Menu font: " + font_get_name(menufont));
            draw_set_color(c_gray);
            draw_text(42 + xx, 106 + yy, "Toggle hotkeys");
            
            if (listeningForKey == 21)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(global.keybindToggleSavestate);
            
            drawMenuOption(20, 3, 42 + xx, 120 + yy, "Savestates: " + key);
            
            if (listeningForKey == 22)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(global.keybindToggleDebug);
            
            drawMenuOption(20, 4, 42 + xx, 134 + yy, "Debug: " + key);
            
            if (listeningForKey == 23)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(global.keybindToggleMusic);
            
            drawMenuOption(20, 5, 42 + xx, 148 + yy, "Music: " + key);
            
            if (listeningForKey == 25)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(global.keybindToggleMusic);
            
            drawMenuOption(20, 6, 42 + xx, 162 + yy, "Fix battle box: " + key);
        }
        
        if (global.menuno == 21)
        {
            draw_text(42 + xx, 44 + yy, "Presets...");
            drawMenuOption(21, 0, 42 + xx, 58 + yy, "Empty splits");
            drawMenuOption(21, 1, 42 + xx, 72 + yy, "Midgame RTA");
            drawMenuOption(21, 2, 42 + xx, 86 + yy, "Waterfall IL");
            drawMenuOption(21, 3, 42 + xx, 100 + yy, "Hotland IL");
            drawMenuOption(21, 4, 42 + xx, 114 + yy, "New Home IL");
            drawMenuOption(21, 5, 42 + xx, 128 + yy, "Right Floor 2");
            drawMenuOption(21, 6, 42 + xx, 142 + yy, "Left Floor 3");
            drawMenuOption(21, 7, 42 + xx, 156 + yy, "Right Floor 3");
            drawMenuOption(21, 8, 42 + xx, 170 + yy, "Long Elevator");
            drawMenuOption(21, 9, 42 + xx, 184 + yy, "True Lab");
        }
        
        if (global.menuno == 22)
        {
            draw_set_color(c_gray);
            draw_text(42 + xx, 44 + yy, "Edit splits...");
            
            if (obj_time.segmentRooms[0] == -1)
            {
                draw_set_color(c_gray);
                draw_text(42 + xx, 62 + yy, "Press Insert and type in a room ID/name");
                draw_text(42 + xx, 74 + yy, "to add a split.");
            }
            
            for (i = 0; i < 10; i++)
            {
                if (obj_time.segmentRooms[i] != -1)
                {
                    text = string(i) + ": ";
                    
                    if (obj_time.segmentRooms[i] < -1)
                    {
                        object = abs(ceil(obj_time.segmentRooms[i]));
                        cutscene = abs(obj_time.segmentRooms[i] - ceil(obj_time.segmentRooms[i])) * 100;
                        text += (object_get_name(object) + ".con = " + string(cutscene));
                    }
                    else if (obj_time.segmentRooms[i] == 0)
                    {
                        text += "Manual split";
                    }
                    else if (obj_time.segmentRooms[i] > 0)
                    {
                        text += room_get_name(floor(obj_time.segmentRooms[i]));
                    }
                    
                    text += (" (" + string(obj_time.segmentRooms[i]) + ")");
                    
                    if (string_length(text) > 40)
                    {
                        text = string_copy(text, 1, 39);
                        text += "...";
                    }
                    
                    if (keyboard_check(vk_shift))
                    {
                        if (i == global.menucoord[22])
                            draw_set_color(c_yellow);
                        else
                            draw_set_color(c_gray);
                        
                        draw_text(42 + xx, 58 + yy + (13 * i), text);
                    }
                    else if (obj_time.timerActive)
                    {
                        draw_set_color(c_gray);
                        draw_text(42 + xx, 58 + yy + (13 * i), text);
                    }
                    else
                    {
                        drawMenuOption(22, i, 42 + xx, 58 + yy + (13 * i), text);
                    }
                }
            }
            
            draw_set_color(c_gray);
            
            if (obj_time.timerActive || obj_time.currentSegment > 0)
                draw_text_transformed(28 + xx, 206 + yy, "Reset timer to edit splits.", 0.5, 0.5, 0);
            else
                draw_text_transformed(28 + xx, 186 + yy, "Insert to add a split#Delete to remove a split#Shift + up/down to move a split", 0.5, 0.5, 0);
        }
        
        if (global.menuno == 23)
        {
            draw_set_color(c_gray);
            draw_text(42 + xx, 44 + yy, "Edit style...");
            drawMenuOption(23, 0, 42 + xx, 58 + yy, "Primary Timer Scale: " + string(round(obj_time.primaryScale * 100)) + "%");
            drawMenuOption(23, 1, 42 + xx, 72 + yy, "Secondary Timer Scale: " + string(round(obj_time.secondaryScale * 100)) + "%");
            drawMenuOption(23, 2, 42 + xx, 86 + yy, "Splits Scale: " + string(round(obj_time.splitsScale * 100)) + "%");
            
            if (obj_time.timerFont == -1)
                fontname = "Arial";
            else
                fontname = font_get_fontname(obj_time.timerFont);
            
            drawMenuOption(23, 3, 42 + xx, 104 + yy, "Timer Font: " + fontname);
            
            if (obj_time.splitsFont == -1)
                fontname = "Arial";
            else
                fontname = font_get_fontname(obj_time.splitsFont);
            
            drawMenuOption(23, 4, 42 + xx, 118 + yy, "Splits Font: " + fontname);
            
            if (obj_time.splitsDisplayMode == 0)
                text = "Split Time | Segment Time";
            else if (obj_time.splitsDisplayMode == 1)
                text = "Split Time";
            else if (obj_time.splitsDisplayMode == 2)
                text = "Segment Time";
            
            drawMenuOption(23, 5, 42 + xx, 136 + yy, "Split Style: " + text);
            drawMenuOption(23, 6, 42 + xx, 154 + yy, "Background Opacity: " + string(round(obj_time.timerBgAlpha * 100)) + "%");
            drawMenuOption(23, 7, 42 + xx, 172 + yy, "Reset to default");
        }
        
        if (global.menuno == 24)
        {
            draw_set_color(c_gray);
            draw_text(42 + xx, 44 + yy, "Edit timer hotkeys...");
            
            if (listeningForKey == 1)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(obj_time.keybindTimerSplit);
            
            drawMenuOption(24, 0, 42 + xx, 58 + yy, "Split: " + key);
            
            if (listeningForKey == 2)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(obj_time.keybindTimerReset);
            
            drawMenuOption(24, 1, 42 + xx, 72 + yy, "Reset: " + key);
            
            if (listeningForKey == 3)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(obj_time.keybindTimerSkip);
            
            drawMenuOption(24, 2, 42 + xx, 86 + yy, "Skip: " + key);
            
            if (listeningForKey == 4)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(obj_time.keybindTimerUndo);
            
            drawMenuOption(24, 3, 42 + xx, 100 + yy, "Undo: " + key);
            
            if (listeningForKey == 5)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(obj_time.keybindTimerToggleSplits);
            
            drawMenuOption(24, 4, 42 + xx, 114 + yy, "Show/Hide Splits: " + key);
        }
        
        if (global.menuno == 25)
        {
            draw_set_color(c_gray);
            draw_text(42 + xx, 44 + yy, "Edit debug hotkeys...");
            
            if (debugOptionPage == 0)
            {
                if (listeningForKey == 6)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindSave);
                
                drawMenuOption(25, 0, 42 + xx, 58 + yy, "Save file: " + key);
                
                if (listeningForKey == 7)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindLoad);
                
                drawMenuOption(25, 1, 42 + xx, 72 + yy, "Load file: " + key);
                
                if (listeningForKey == 18)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindSaveSlot);
                
                drawMenuOption(25, 2, 42 + xx, 86 + yy, "File slot: " + key);
                
                if (listeningForKey == 8)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindRun);
                
                drawMenuOption(25, 3, 42 + xx, 100 + yy, "Run: " + key);
                
                if (listeningForKey == 9)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindNextRoom);
                
                drawMenuOption(25, 4, 42 + xx, 114 + yy, "Go to next room: " + key);
                
                if (listeningForKey == 10)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindPrevRoom);
                
                drawMenuOption(25, 5, 42 + xx, 128 + yy, "Go to previous room: " + key);
                
                if (listeningForKey == 11)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindRestartRoom);
                
                drawMenuOption(25, 6, 42 + xx, 142 + yy, "Restart room: " + key);
                
                if (listeningForKey == 24)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindStartBattle);
                
                drawMenuOption(25, 7, 42 + xx, 156 + yy, "Start battle: " + key);
                
                if (listeningForKey == 12)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindNoclip);
                
                drawMenuOption(25, 8, 42 + xx, 170 + yy, "Noclip: " + key);
                draw_set_color(c_white);
                draw_text(250 + xx, 195 + yy, "Page 1");
            }
            else if (debugOptionPage == 1)
            {
                if (listeningForKey == 19)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindMute);
                
                drawMenuOption(25, 9, 42 + xx, 58 + yy, "Stop all audio: " + key);
                
                if (listeningForKey == 13)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindSpeedUp);
                
                drawMenuOption(25, 10, 42 + xx, 72 + yy, "Toggle speed up (200FPS): " + key);
                
                if (listeningForKey == 14)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindSlowDown);
                
                drawMenuOption(25, 11, 42 + xx, 86 + yy, "Toggle slow down (10FPS): " + key);
                
                if (listeningForKey == 15)
                    key = "Listening... (Esc to unbind)";
                else
                    key = getCharName(global.keybindRestartGame);
                
                drawMenuOption(25, 12, 42 + xx, 100 + yy, "Restart game: " + key);
                
                if (global.fixedFunEvents)
                    text = "Always trigger Fun events: ON";
                else
                    text = "Always trigger Fun events: OFF";
                
                drawMenuOption(25, 13, 42 + xx, 118 + yy, text);
                draw_set_color(c_white);
                draw_text(250 + xx, 195 + yy, "Page 2");
            }
        }
        
        if (global.menuno == 26)
        {
            draw_set_color(c_gray);
            draw_text(42 + xx, 44 + yy, "Edit savestate hotkeys...");
            
            if (listeningForKey == 16)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(global.keybindSavestate);
            
            drawMenuOption(26, 0, 42 + xx, 58 + yy, "Save state: " + key);
            
            if (listeningForKey == 17)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(global.keybindLoadstate);
            
            drawMenuOption(26, 1, 42 + xx, 72 + yy, "Load state: " + key);
            
            if (listeningForKey == 20)
                key = "Listening... (Esc to unbind)";
            else
                key = getCharName(global.keybindStateslot);
            
            drawMenuOption(26, 2, 42 + xx, 86 + yy, "Savestate slot: " + key);
        }
    }
    
    comment = "Draw text input";
    
    if (global.textInputActive)
    {
        global.textInputString = keyboard_string;
        
        if (keyboard_check_pressed(vk_anykey))
            global.textInputError = "";
        
        textDisplay = "";
        line = "";
        
        for (i = 1; i <= string_length(global.textInputString); i++)
        {
            line += string_char_at(global.textInputString, i);
            
            if (string_width(line) >= 250 || i == string_length(global.textInputString))
            {
                textDisplay += (line + " #");
                
                if (i != string_length(global.textInputString))
                    line = "";
            }
        }
        
        if (textDisplay == "")
            textDisplay = " ";
        
        draw_set_color(c_white);
        draw_rectangle(22 + xx, (130 + yy) - string_height(global.textInputPrompt) - string_height(textDisplay), 296 + xx, 216 + yy, false);
        draw_set_color(c_black);
        draw_rectangle(25 + xx, (133 + yy) - string_height(global.textInputPrompt) - string_height(textDisplay), 293 + xx, 213 + yy, false);
        draw_set_color(c_white);
        draw_text(30 + xx, (138 + yy) - string_height(global.textInputPrompt) - string_height(textDisplay), global.textInputPrompt);
        draw_text(30 + xx, (148 + yy) - string_height(textDisplay), textDisplay);
        textCursorTimer++;
        
        if (keyboard_check(vk_anykey) || textCursorTimer >= room_speed)
            textCursorTimer = 0;
        
        if (textCursorTimer < (room_speed / 2))
            draw_line(30 + xx + string_width(line), 132 + yy, 30 + xx + string_width(line), 148 + yy);
        
        draw_set_color(c_red);
        draw_text(30 + xx, 153 + yy, global.textInputError);
        draw_set_color(c_gray);
        draw_text(30 + xx, 178 + yy, "Enter to confirm#Ctrl+Backspace to cancel");
    }
    
    comment = "Input code (13 is Z, 16 is X, 17 is C)";
    
    if (listeningForKey > 0)
    {
        if (keyboard_check_pressed(vk_anykey))
        {
            keyboard_clear(keyboard_lastkey);
            keyChoose = keyboard_lastkey;
            
            if (keyChoose == 27)
                keyChoose = -1;
            
            if (listeningForKey == 1)
                obj_time.keybindTimerSplit = keyChoose;
            else if (listeningForKey == 2)
                obj_time.keybindTimerReset = keyChoose;
            else if (listeningForKey == 3)
                obj_time.keybindTimerSkip = keyChoose;
            else if (listeningForKey == 4)
                obj_time.keybindTimerUndo = keyChoose;
            else if (listeningForKey == 5)
                obj_time.keybindTimerToggleSplits = keyChoose;
            else if (listeningForKey == 6)
                global.keybindSave = keyChoose;
            else if (listeningForKey == 7)
                global.keybindLoad = keyChoose;
            else if (listeningForKey == 8)
                global.keybindRun = keyChoose;
            else if (listeningForKey == 9)
                global.keybindNextRoom = keyChoose;
            else if (listeningForKey == 10)
                global.keybindPrevRoom = keyChoose;
            else if (listeningForKey == 11)
                global.keybindRestartRoom = keyChoose;
            else if (listeningForKey == 12)
                global.keybindNoclip = keyChoose;
            else if (listeningForKey == 13)
                global.keybindSpeedUp = keyChoose;
            else if (listeningForKey == 14)
                global.keybindSlowDown = keyChoose;
            else if (listeningForKey == 15)
                global.keybindRestartGame = keyChoose;
            else if (listeningForKey == 16)
                global.keybindSavestate = keyChoose;
            else if (listeningForKey == 17)
                global.keybindLoadstate = keyChoose;
            else if (listeningForKey == 18)
                global.keybindSaveSlot = keyChoose;
            else if (listeningForKey == 19)
                global.keybindMute = keyChoose;
            else if (listeningForKey == 20)
                global.keybindStateslot = keyChoose;
            else if (listeningForKey == 21)
                global.keybindToggleSavestate = keyChoose;
            else if (listeningForKey == 22)
                global.keybindToggleDebug = keyChoose;
            else if (listeningForKey == 23)
                global.keybindToggleMusic = keyChoose;
            else if (listeningForKey == 24)
                global.keybindStartBattle = keyChoose;
            else if (listeningForKey == 25)
                global.keybindFixBarrier = keyChoose;
            
            listeningForKey = 0;
        }
    }
    
    if (myTextboxIsOpen)
    {
        myTextboxIsOpen = instance_exists(myTextbox);
        confirm = 0;
    }
    else if (global.textInputActive)
    {
        confirm = keyboard_check_pressed(vk_enter);
    }
    else
    {
        confirm = keyboard_multicheck_pressed(13);
    }
    
    confirmSound = 111;
    confirmSoundVolume = 1;
    confirmSoundPitch = 1;
    
    if (confirm)
    {
        if (global.menuno == 5)
        {
            if (global.menucoord[5] == 0)
            {
                global.menuno = 9;
                script_execute(scr_itemuseb, global.menucoord[1], global.item[global.menucoord[1]]);
            }
            
            if (global.menucoord[5] == 1)
            {
                global.menuno = 9;
                script_execute(scr_itemdesc, global.item[global.menucoord[1]]);
                script_execute(scr_writetext, 0, "x", 0, 0);
            }
            
            if (global.menucoord[5] == 2)
            {
                global.menuno = 9;
                dontthrow = 0;
                
                if (global.item[global.menucoord[1]] != 23 && global.item[global.menucoord[1]] != 27 && global.item[global.menucoord[1]] != 54 && global.item[global.menucoord[1]] != 56 && global.item[global.menucoord[1]] != 57)
                {
                    script_execute(scr_writetext, 12, "x", 0, 0);
                }
                else
                {
                    if (global.item[global.menucoord[1]] == 23)
                        script_execute(scr_writetext, 23, "x", 0, 0);
                    
                    if (global.item[global.menucoord[1]] == 27)
                    {
                        script_execute(scr_writetext, 0, "* (You put the dog on the&  ground.)/%%", 0, 0);
                        
                        if (instance_exists(obj_rarependant))
                        {
                            with (obj_rarependant)
                                con = 1;
                        }
                    }
                    
                    if (global.item[global.menucoord[1]] == 54)
                    {
                        script_execute(scr_writetext, 0, "* (You threw the Bad Memory&  away.^1)&* (But it came back.)/%%", 0, 0);
                        dontthrow = 1;
                    }
                    
                    if (global.item[global.menucoord[1]] == 56)
                    {
                        if (!instance_exists(obj_undyne_friendc))
                        {
                            script_execute(scr_writetext, 0, "* (Despite what seems like&  common sense^1, you threw&  away the letter.)/%%", 0, 0);
                            global.flag[494] = 1;
                        }
                        else
                        {
                            global.faceemotion = 1;
                            script_execute(scr_writetext, 0, "* Hey^1! Don't throw that&  away^1! Just deliver it!/%%", 5, 37);
                            dontthrow = 1;
                        }
                    }
                    
                    if (global.item[global.menucoord[1]] == 57)
                    {
                        script_execute(scr_writetext, 0, "* (The letter is too powerful to&  throw away.^1)&* (It gets the better of you.)/%%", 0, 0);
                        dontthrow = 1;
                    }
                }
                
                if (dontthrow == 0)
                    script_execute(scr_itemshift, global.menucoord[1], 0);
            }
        }
        
        if (global.menuno == 3)
        {
            global.menuno = 9;
            script_execute(scr_itemuseb, global.menucoord[3], global.phone[global.menucoord[3]]);
        }
        
        if (global.menuno == 6)
        {
            global.menuno = 9;
            script_execute(scr_storageget, global.item[global.menucoord[6]], 300);
            
            if (noroom == 0)
            {
                script_execute(scr_writetext, 16, "x", 0, 0);
                script_execute(scr_itemshift, global.menucoord[6], 0);
            }
            else
            {
                script_execute(scr_writetext, 19, "x", 0, 0);
            }
        }
        
        if (global.menuno == 7)
        {
            global.menuno = 9;
            script_execute(scr_itemget, global.flag[global.menucoord[7] + 300]);
            
            if (noroom == 0)
            {
                script_execute(scr_writetext, 17, "x", 0, 0);
                scr_storageshift(global.menucoord[7], 0, 300);
            }
            else
            {
                script_execute(scr_writetext, 18, "x", 0, 0);
            }
        }
        
        if (global.menuno == 1)
        {
            global.menuno = 5;
            global.menucoord[5] = 0;
        }
        
        if (global.menuno == 0)
            global.menuno += (global.menucoord[0] + 1);
        
        if (global.menuno == 3)
        {
            script_execute(scr_phonename);
            global.menucoord[3] = 0;
        }
        
        if (global.menuno == 1)
        {
            if (global.item[0] != 0)
            {
                global.menucoord[1] = 0;
                script_execute(scr_itemname);
            }
            else
            {
                global.menuno = 0;
            }
        }
        
        if (global.textInputActive)
        {
            global.lastEnteredValue = global.textInputString;
            global.textInputError = "";
            
            if (global.textInputType == "number" || global.textInputType == "integer")
            {
                convertedValue = getNumberFromString(global.lastEnteredValue);
                
                if (convertedValue == "NaN")
                    global.textInputError = 'Expected a value of type "' + global.textInputType + '"';
                else if (global.textInputType == "integer" && convertedValue != floor(convertedValue))
                    global.textInputError = 'Expected a value of type "' + global.textInputType + '"';
                else if (global.textInputUsingRange && (convertedValue < global.textInputRangeStart || convertedValue > global.textInputRangeEnd))
                    global.textInputError = "Expected a value between " + string(global.textInputRangeStart) + " and " + string(global.textInputRangeEnd);
                
                global.lastEnteredValue = convertedValue;
            }
            else if (global.textInputType == "string")
            {
            }
            else if (global.textInputType == "room")
            {
                comment = "Search for a room by name first; if that fails, then search by number";
                convertedValue = getRoomFromName(global.lastEnteredValue);
                
                if (convertedValue == -1)
                {
                    convertedValue = getNumberFromString(global.lastEnteredValue);
                    
                    if (convertedValue == "NaN" || (convertedValue != floor(convertedValue) && global.textInputType == "room") || convertedValue < room_first || convertedValue > room_last)
                        global.textInputError = "Not a room name or room number";
                }
                
                global.lastEnteredValue = convertedValue;
            }
            else if (global.textInputType == "splitroom")
            {
                comment = "Same as above, but supports negative and decimal values for my scuffed-ass splits system";
                convertedValue = getRoomFromName(global.lastEnteredValue);
                
                if (convertedValue == -1)
                {
                    convertedValue = getNumberFromString(global.lastEnteredValue);
                    
                    if (convertedValue == "NaN" || convertedValue > room_last)
                        global.textInputError = "Not a room name or room number";
                }
                
                global.lastEnteredValue = convertedValue;
            }
            else if (global.textInputType == "battle")
            {
                comment = "Search for a boss/miniboss by name first; if that fails, then search by number";
                convertedValue = getBattlegroupFromName(global.lastEnteredValue);
                
                if (convertedValue == -1)
                {
                    convertedValue = getNumberFromString(global.lastEnteredValue);
                    
                    if (convertedValue == "NaN" || convertedValue != floor(convertedValue) || convertedValue < 1 || convertedValue == 29 || (convertedValue > 36 && convertedValue < 40) || (convertedValue > 95 && convertedValue < 100) || (convertedValue > 101 && convertedValue < 120) || (convertedValue > 136 && convertedValue < 140) || (convertedValue > 140 && convertedValue < 255) || convertedValue > 256)
                        global.textInputError = "Not a valid battlegroup name/ID";
                }
                
                global.lastEnteredValue = convertedValue;
            }
            else
            {
                global.textInputError = 'Unknown type "' + global.textInputType + '"' + " (devs need to fix this!!)";
            }
            
            if (global.textInputError != "")
            {
                confirmSound = 42;
            }
            else
            {
                global.textInputActive = 0;
                global.textInputState++;
            }
        }
        
        if (global.menuno == 10)
        {
            if (global.menucoord[10] == 0)
                global.menuno = 11;
            else if (global.menucoord[10] == 1)
                global.menuno = 19;
            else
                global.menuno = global.menucoord[10] + 10;
        }
        else if (global.menuno == 11)
        {
            if (offset == 1 && global.menucoord[11] == 0)
                url_open("https://github.com/fixylol/UndertalePracticeMod/releases/latest");
            
            if (global.menucoord[11] == (0 + offset))
            {
                if (keyboard_check(vk_control))
                {
                    global.menuno = 25;
                }
                else
                {
                    global.debugTemp += 1;
                    
                    if (global.debugTemp > 1)
                    {
                        global.debugTemp = 0;
                        confirmSound = 110;
                    }
                }
            }
            
            if (global.menucoord[11] == (1 + offset))
            {
                if (keyboard_check(vk_control))
                {
                    global.menuno = 26;
                }
                else
                {
                    global.savestatesTemp -= 1;
                    
                    if (global.savestatesTemp == 0)
                        confirmSound = 110;
                    
                    if (global.savestatesTemp < 0)
                        global.savestatesTemp = 2;
                }
            }
            
            if (global.menucoord[11] == (2 + offset))
            {
                global.musicEnabled += 1;
                
                if (global.musicEnabled > 1)
                {
                    global.musicEnabled = 0;
                    
                    if (caster_is_playing(global.currentsong))
                        caster_set_volume(global.currentsong, 0);
                    else if (caster_is_playing(global.batmusic))
                        caster_set_volume(global.batmusic, 0);
                }
                else if (global.musicEnabled == 1)
                {
                    if (caster_is_playing(global.currentsong))
                        caster_set_volume(global.currentsong, global.currentsongv);
                    else if (caster_is_playing(global.batmusic))
                        caster_set_volume(global.batmusic, global.batmusicv);
                }
            }
            
            if (global.menucoord[11] == (3 + offset))
                global.menuno = 18;
            
            if (global.menucoord[11] == (4 + offset))
            {
                if (keyboard_check(vk_control))
                    extraMDSOptions = 1;
                
                if (extraMDSOptions > 0)
                {
                    switch (global.textInputState)
                    {
                        case 0:
                            prompt("Set Mad Dummy's dialog (Flag 14)", 2, "number");
                            break;
                        
                        case 1:
                            dummyDialog = global.lastEnteredValue;
                            prompt("Set Napstablook's dialog (Flag 36)", 1, "number");
                            break;
                        
                        case 2:
                            napstaDialog = global.lastEnteredValue;
                            global.dummyPractice = 1;
                            global.plot = 115;
                            global.flag[14] = dummyDialog;
                            global.flag[36] = napstaDialog;
                            global.item[0] = 26;
                            global.item[1] = 0;
                            global.item[2] = 0;
                            global.item[3] = 0;
                            global.item[4] = 0;
                            global.item[5] = 0;
                            global.item[6] = 0;
                            global.item[7] = 0;
                            global.item[8] = 0;
                            global.border = 0;
                            global.mercy = 0;
                            caster_free(global.currentsong);
                            global.currentsong = caster_load("music/ambientwater.ogg");
                            global.currentsongi = caster_loop(global.currentsong, 0.8, 1);
                            obj_time.timerEnable = 0;
                            obj_time.timerActive = 0;
                            savePracticeOptions();
                            global.menuno = -1;
                            global.interact = 0;
                            extraMDSOptions = 0;
                            room_goto(room_water_trashzone2);
                            break;
                    }
                }
                else
                {
                    global.dummyPractice = 1;
                    global.plot = 115;
                    global.flag[14] = 2;
                    global.flag[36] = napstaDialog;
                    global.item[0] = 26;
                    global.item[1] = 0;
                    global.item[2] = 0;
                    global.item[3] = 0;
                    global.item[4] = 0;
                    global.item[5] = 0;
                    global.item[6] = 0;
                    global.item[7] = 0;
                    global.item[8] = 0;
                    global.border = 0;
                    global.mercy = 0;
                    caster_free(global.currentsong);
                    global.currentsong = caster_load("music/ambientwater.ogg");
                    global.currentsongi = caster_loop(global.currentsong, 0.8, 1);
                    obj_time.timerEnable = 0;
                    obj_time.timerActive = 0;
                    savePracticeOptions();
                    global.menuno = -1;
                    global.interact = 0;
                    room_goto(room_water_trashzone2);
                }
            }
            
            if (global.menucoord[11] == (5 + offset))
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Type in a room (by number or by name)#to teleport to.", room_get_name(room), "room");
                        break;
                    
                    case 1:
                        confirmSound = 1;
                        confirmSoundVolume = 0.9;
                        room_goto(global.lastEnteredValue);
                        savePracticeOptions();
                        global.menuno = -1;
                        global.interact = 0;
                        break;
                }
            }
            
            if (global.menucoord[11] == (6 + offset))
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Boss name or Battlegroup ID:", "Sans", "battle", 1, 256);
                        break;
                    
                    case 1:
                        confirmSound = 96;
                        global.battlegroup = global.lastEnteredValue;
                        global.menuno = -1;
                        global.border = 0;
                        global.mercy = 0;
                        savePracticeOptions();
                        obj_time.timerEnable = 0;
                        instance_create(0, 0, obj_battleblcon);
                        break;
                }
            }
            
            if (global.menucoord[11] == (7 + offset))
            {
                global.border = 0;
                global.mercy = 0;
            }
        }
        else if (global.menuno == 12)
        {
            if (global.menucoord[12] == 0)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your Name.", global.charname, "string");
                        break;
                    
                    case 1:
                        global.charname = global.lastEnteredValue;
                        break;
                }
            }
            
            if (global.menucoord[12] == 1)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your LV (must be between 1 and 20).", global.lv, "integer", 1, 20);
                        break;
                    
                    case 1:
                        if (global.lastEnteredValue == 1)
                            global.xp = 0;
                        
                        if (global.lastEnteredValue == 2)
                            global.xp = 10;
                        
                        if (global.lastEnteredValue == 3)
                            global.xp = 30;
                        
                        if (global.lastEnteredValue == 4)
                            global.xp = 70;
                        
                        if (global.lastEnteredValue == 5)
                            global.xp = 120;
                        
                        if (global.lastEnteredValue == 6)
                            global.xp = 200;
                        
                        if (global.lastEnteredValue == 7)
                            global.xp = 300;
                        
                        if (global.lastEnteredValue == 8)
                            global.xp = 500;
                        
                        if (global.lastEnteredValue == 9)
                            global.xp = 800;
                        
                        if (global.lastEnteredValue == 10)
                            global.xp = 1200;
                        
                        if (global.lastEnteredValue == 11)
                            global.xp = 1700;
                        
                        if (global.lastEnteredValue == 12)
                            global.xp = 2500;
                        
                        if (global.lastEnteredValue == 13)
                            global.xp = 3500;
                        
                        if (global.lastEnteredValue == 14)
                            global.xp = 5000;
                        
                        if (global.lastEnteredValue == 15)
                            global.xp = 7000;
                        
                        if (global.lastEnteredValue == 16)
                            global.xp = 10000;
                        
                        if (global.lastEnteredValue == 17)
                            global.xp = 15000;
                        
                        if (global.lastEnteredValue == 18)
                            global.xp = 25000;
                        
                        if (global.lastEnteredValue == 19)
                            global.xp = 50000;
                        
                        if (global.lastEnteredValue == 20)
                            global.xp = 99999;
                        
                        scr_levelup();
                        global.hp = global.maxhp;
                        break;
                }
            }
            
            if (global.menucoord[12] == 2)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your EXP.", global.xp, "integer", 0, 99999);
                        break;
                    
                    case 1:
                        global.xp = global.lastEnteredValue;
                        scr_levelup();
                        break;
                }
            }
            
            if (global.menucoord[12] == 3)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your health.", global.hp);
                        break;
                    
                    case 1:
                        global.hp = global.lastEnteredValue;
                        break;
                }
            }
            
            if (global.menucoord[12] == 4)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your max health.", global.maxhp);
                        break;
                    
                    case 1:
                        global.maxhp = global.lastEnteredValue;
                        break;
                }
            }
            
            if (global.menucoord[12] == 5)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your AT.", global.at);
                        break;
                    
                    case 1:
                        global.at = global.lastEnteredValue;
                        break;
                }
            }
            
            if (global.menucoord[12] == 6)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your DF.", global.df);
                        break;
                    
                    case 1:
                        global.df = global.lastEnteredValue;
                        break;
                }
            }
            
            if (global.menucoord[12] == 7)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your WEAPON.", global.weapon);
                        break;
                    
                    case 1:
                        equipItem("weapon", global.lastEnteredValue);
                        break;
                }
            }
            
            if (global.menucoord[12] == 8)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your ARMOR.", global.armor);
                        break;
                    
                    case 1:
                        equipItem("armor", global.lastEnteredValue);
                        break;
                }
            }
            
            if (global.menucoord[12] == 9)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your Gold.", global.gold);
                        break;
                    
                    case 1:
                        obj_time.goldamount = global.lastEnteredValue - global.gold;
                        obj_time.goldtext = 30;
                        global.gold = global.lastEnteredValue;
                        snd_play(snd_dumbvictory);
                        break;
                }
            }
        }
        else if (global.menuno == 13)
        {
            if (global.menucoord[13] == 0)
                global.menuno = 15;
            
            if (global.menucoord[13] == 1)
                global.menuno = 16;
        }
        else if (global.menuno == 14)
        {
            if (global.menucoord[14] == 0)
            {
                switch (global.textInputState)
                {
                    case 0:
                        comment = "range is [0, 511]; note that ranges are always inclusive on both ends";
                        prompt("Flag ID to change:", 0, "integer", 0, 511);
                        break;
                    
                    case 1:
                        flagtochange = global.lastEnteredValue;
                        prompt("Value to change flag " + string(flagtochange) + " to.", global.flag[flagtochange]);
                        break;
                    
                    case 2:
                        global.flag[flagtochange] = global.lastEnteredValue;
                        break;
                }
            }
            
            if (global.menucoord[14] == 1)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Section of flag: ", "", "string");
                        break;
                    
                    case 1:
                        section = global.lastEnteredValue;
                        prompt("Name of flag in " + section + ": ", "", "string");
                        break;
                    
                    case 2:
                        flagname = global.lastEnteredValue;
                        prompt("Value to change " + section + "." + flagname + " to:", "", "string");
                        break;
                    
                    case 3:
                        ini_open("undertale.ini");
                        ini_write_string(section, flagname, global.lastEnteredValue);
                        ini_close();
                        break;
                }
            }
            
            if (global.menucoord[14] == 2)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Change plot value to:", global.plot);
                        break;
                    
                    case 1:
                        global.plot = global.lastEnteredValue;
                        break;
                }
            }
            
            if (global.menucoord[14] == 3)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Change Fun value to:", global.flag[5], "integer", 0, 99);
                        break;
                    
                    case 1:
                        global.flag[5] = global.lastEnteredValue;
                        ini_open("undertale.ini");
                        ini_write_real("General", "fun", global.lastEnteredValue);
                        ini_close();
                        break;
                }
            }
            
            if (global.menucoord[14] == 4)
            {
                global.monstertaleSkippable++;
                
                if (global.monstertaleSkippable > 1)
                    global.monstertaleSkippable = 0;
            }
            
            if (global.menucoord[14] == 5)
            {
                global.fixedblcon++;
                
                if (global.fixedblcon > 5)
                    global.fixedblcon = 0;
            }
            
            if (global.menucoord[14] == 6)
                global.menuno = 20;
        }
        else if (global.menuno == 15 || global.menuno == 16)
        {
            if (global.menuno == 15)
                itemmenuId = itemmenuA[global.menucoord[global.menuno]];
            
            if (global.menuno == 16)
                itemmenuId = itemmenuB[global.menucoord[global.menuno]];
            
            scr_itemget(itemmenuId);
            global.msc = 0;
            global.typer = 5;
            global.facechoice = 0;
            
            if (noroom)
            {
                confirmSound = 123;
                global.msg[0] = "* (You're carrying too much.)/%%";
            }
            else
            {
                confirmSound = 109;
                confirmSoundVolume = 0.5;
                event_user(0);
                global.msg[0] = "* (You got the " + itemmenuName + ".)/%%";
            }
            
            myTextbox = instance_create(0, 0, obj_dialoguer);
            myTextbox.depth = depth - 1;
            myTextbox.writer.depth = depth - 2;
            myTextboxIsOpen = 1;
        }
        else if (global.menuno == 17)
        {
        }
        else if (global.menuno == 18)
        {
            if (global.menucoord[18] == 0)
            {
                global.weaponPracticeMode = 1;
                
                if (weaponPracticeBoss == 0)
                    global.battlegroup = 101;
                else if (weaponPracticeBoss == 1)
                    global.battlegroup = 81;
                else if (weaponPracticeBoss == 2)
                    global.battlegroup = 92;
                else if (weaponPracticeBoss == 3)
                    global.battlegroup = 2;
                
                global.weaponPracticeBoss = weaponPracticeBoss;
                global.weaponPracticeAttacks = weaponPracticeAttacks;
                global.weaponPracticeInv = weaponPracticeBossInv;
                
                if (weaponPracticeWeapon == 0)
                {
                    global.weapon = 47;
                    global.wstrength = 10;
                }
                else if (weaponPracticeWeapon == 1)
                {
                    global.weapon = 25;
                    global.wstrength = 7;
                }
                else if (weaponPracticeWeapon == 2)
                {
                    global.weapon = 49;
                    global.wstrength = 12;
                }
                else if (weaponPracticeWeapon == 3)
                {
                    global.weapon = 45;
                    global.wstrength = 2;
                }
                
                global.lv = weaponPracticeLV;
                global.weaponPracticePlayerInv = weaponPracticePlayerInv;
                global.weaponPracticeMttRatings = weaponPracticeMttRatings;
                global.weaponPracticeTurnGoal = weaponPracticeTurnGoal;
                global.menuno = -1;
                global.savestates = global.savestatesTemp;
                caster_free(all);
                savePracticeOptions();
                obj_time.timerEnable = 0;
                global.border = 0;
                global.mercy = 0;
                room_goto(room_battle);
            }
            else if (global.menucoord[18] == 1)
            {
                weaponPracticeBoss++;
                
                if (weaponPracticeBoss == 1)
                {
                    weaponPracticeLV = 9;
                    weaponPracticeWeapon = 0;
                }
                else if (weaponPracticeBoss == 2)
                {
                    weaponPracticeLV = 10;
                    weaponPracticeWeapon = 1;
                    weaponPracticeTurnGoal = 14;
                }
                
                if (weaponPracticeBoss > 2)
                {
                    weaponPracticeLV = 4;
                    weaponPracticeWeapon = 0;
                    weaponPracticeTurnGoal = 0;
                }
                
                if (weaponPracticeBoss > 3)
                    weaponPracticeBoss = 0;
            }
            else if (global.menucoord[18] == 2)
            {
                weaponPracticeWeapon++;
                
                if (weaponPracticeWeapon > 3)
                    weaponPracticeWeapon = 0;
            }
            else if (global.menucoord[18] == 3)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your LV (must be between 1 and 20).", weaponPracticeLV, "integer", 1, 20);
                        break;
                    
                    case 1:
                        weaponPracticeLV = global.lastEnteredValue;
                        break;
                }
            }
            else if (global.menucoord[18] == 4)
            {
                weaponPracticeAttacks++;
                
                if (weaponPracticeAttacks > 1)
                    weaponPracticeAttacks = 0;
            }
            else if (global.menucoord[18] == 5)
            {
                weaponPracticeBossInv++;
                
                if (weaponPracticeBossInv > 1)
                    weaponPracticeBossInv = 0;
            }
            else if (global.menucoord[18] == 6)
            {
                weaponPracticePlayerInv++;
                
                if (weaponPracticePlayerInv > 1)
                    weaponPracticePlayerInv = 0;
            }
            else if (global.menucoord[18] == 7)
            {
                switch (global.textInputState)
                {
                    case 0:
                        prompt("Set your turn goal (0 to disable).", weaponPracticeTurnGoal, "integer", 0, 99);
                        break;
                    
                    case 1:
                        weaponPracticeTurnGoal = global.lastEnteredValue;
                        break;
                }
            }
            else if (global.menucoord[18] == 8)
            {
                weaponPracticeMttRatings++;
                
                if (weaponPracticeMttRatings > 1)
                    weaponPracticeMttRatings = 0;
            }
        }
        else if (global.menuno == 19)
        {
            if (global.menucoord[19] == 0)
            {
                obj_time.timerEnable++;
                
                if (obj_time.timerEnable > 1)
                {
                    obj_time.timerEnable = 0;
                    confirmSound = 110;
                }
            }
            
            if (global.menucoord[19] == 1)
                global.menuno = 21;
            
            if (global.menucoord[19] == 2)
            {
                global.menuno = 22;
                global.menucoord[22] = 0;
            }
            
            if (global.menucoord[19] == 3)
                global.menuno = 23;
            
            if (global.menucoord[19] == 4)
                global.menuno = 24;
            
            if (global.menucoord[19] == 5)
            {
                obj_time.primaryTiming++;
                
                if (obj_time.primaryTiming > 1)
                    obj_time.primaryTiming = 0;
            }
            
            if (global.menucoord[19] == 6)
            {
                obj_time.primaryUpdate++;
                
                if (obj_time.primaryUpdate > 1)
                    obj_time.primaryUpdate = 0;
            }
            
            if (global.menucoord[19] == 7)
            {
                obj_time.secondaryTiming++;
                
                if (obj_time.secondaryTiming > 1)
                    obj_time.secondaryTiming = 0;
            }
            
            if (global.menucoord[19] == 8)
            {
                obj_time.secondaryUpdate++;
                
                if (obj_time.secondaryUpdate > 1)
                    obj_time.secondaryUpdate = 0;
            }
        }
        else if (global.menuno == 20)
        {
            if (global.menucoord[20] == 0)
            {
                global.checkUpdate++;
                
                if (global.checkUpdate > 1)
                    global.checkUpdate = 0;
            }
            
            if (global.menucoord[20] == 1)
            {
                obj_time.versionRequest = 0;
                obj_time.versionCheck = 0;
                global.modUpToDate = -2;
            }
            
            if (global.menucoord[20] == 2)
            {
                global.debugMenuFont++;
                
                if (global.debugMenuFont > 2)
                    global.debugMenuFont = 0;
            }
            
            if (global.menucoord[20] == 3)
                listeningForKey = 21;
            
            if (global.menucoord[20] == 4)
                listeningForKey = 22;
            
            if (global.menucoord[20] == 5)
                listeningForKey = 23;
            
            if (global.menucoord[20] == 6)
                listeningForKey = 25;
        }
        else if (global.menuno == 21)
        {
            with (obj_time)
            {
                if (global.menucoord[21] == 0)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                }
                
                if (global.menucoord[21] == 1)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 82;
                    segmentRooms[1] = -1039.16;
                    segmentRooms[2] = 141;
                    segmentRooms[3] = 157;
                    segmentRooms[4] = 169;
                    segmentRooms[5] = 187.19;
                    segmentRooms[6] = 217;
                    segmentRooms[7] = 226;
                    segmentRooms[8] = 237;
                }
                
                if (global.menucoord[21] == 2)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 82;
                    segmentRooms[1] = -1039.16;
                    segmentRooms[2] = 141;
                }
                
                if (global.menucoord[21] == 3)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 141;
                    segmentRooms[1] = 157;
                    segmentRooms[2] = 169;
                    segmentRooms[3] = 187.19;
                    segmentRooms[4] = 217;
                }
                
                if (global.menucoord[21] == 4)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 217;
                    segmentRooms[1] = 226;
                    segmentRooms[2] = 237;
                }
                
                if (global.menucoord[21] == 5)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 141;
                    segmentRooms[1] = 157;
                }
                
                if (global.menucoord[21] == 6)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 157;
                    segmentRooms[1] = 169;
                }
                
                if (global.menucoord[21] == 7)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 169;
                    segmentRooms[1] = 187.19;
                }
                
                if (global.menucoord[21] == 8)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 187.19;
                    segmentRooms[1] = 217;
                }
                
                if (global.menucoord[21] == 9)
                {
                    for (i = 0; i < 11; i++)
                    {
                        segmentRooms[i] = -1;
                        segmentTimes[i] = 0;
                        splitTimes[i] = 0;
                    }
                    
                    segmentRooms[0] = 244;
                    segmentRooms[1] = -1566.04;
                }
            }
        }
        else if (global.menuno == 22 && obj_time.currentSegment == 0 && obj_time.timerActive == 0)
        {
        }
        else if (global.menuno == 23)
        {
            if (global.menucoord[23] == 3)
            {
                if (obj_time.timerFont == -1)
                    obj_time.timerFont = 2;
                else if (obj_time.timerFont == 2)
                    obj_time.timerFont = 8;
                else if (obj_time.timerFont == 8)
                    obj_time.timerFont = 9;
                else if (obj_time.timerFont == 9)
                    obj_time.timerFont = -1;
            }
            
            if (global.menucoord[23] == 4)
            {
                if (obj_time.splitsFont == -1)
                    obj_time.splitsFont = 2;
                else if (obj_time.splitsFont == 2)
                    obj_time.splitsFont = 8;
                else if (obj_time.splitsFont == 8)
                    obj_time.splitsFont = 9;
                else if (obj_time.splitsFont == 9)
                    obj_time.splitsFont = -1;
            }
            
            if (global.menucoord[23] == 5)
            {
                obj_time.splitsDisplayMode++;
                
                if (obj_time.splitsDisplayMode > 2)
                    obj_time.splitsDisplayMode = 0;
            }
            
            if (global.menucoord[23] == 7)
            {
                obj_time.timerBgAlpha = 0.6;
                obj_time.primaryScale = 1.5;
                obj_time.secondaryScale = 1;
                obj_time.splitsScale = 1;
                obj_time.splitsDisplayMode = 0;
                obj_time.timerFont = 2;
                obj_time.splitsFont = 2;
            }
        }
        else if (global.menuno == 24)
        {
            if (global.menucoord[24] == 0)
                listeningForKey = 1;
            
            if (global.menucoord[24] == 1)
                listeningForKey = 2;
            
            if (global.menucoord[24] == 2)
                listeningForKey = 3;
            
            if (global.menucoord[24] == 3)
                listeningForKey = 4;
            
            if (global.menucoord[24] == 4)
                listeningForKey = 5;
        }
        else if (global.menuno == 25)
        {
            if (global.menucoord[25] == 0)
                listeningForKey = 6;
            
            if (global.menucoord[25] == 1)
                listeningForKey = 7;
            
            if (global.menucoord[25] == 2)
                listeningForKey = 18;
            
            if (global.menucoord[25] == 3)
                listeningForKey = 8;
            
            if (global.menucoord[25] == 4)
                listeningForKey = 9;
            
            if (global.menucoord[25] == 5)
                listeningForKey = 10;
            
            if (global.menucoord[25] == 6)
                listeningForKey = 11;
            
            if (global.menucoord[25] == 7)
                listeningForKey = 24;
            
            if (global.menucoord[25] == 8)
                listeningForKey = 12;
            
            if (global.menucoord[25] == 9)
                listeningForKey = 19;
            
            if (global.menucoord[25] == 10)
                listeningForKey = 13;
            
            if (global.menucoord[25] == 11)
                listeningForKey = 14;
            
            if (global.menucoord[25] == 12)
                listeningForKey = 15;
            
            if (global.menucoord[25] == 13)
            {
                global.fixedFunEvents++;
                
                if (global.fixedFunEvents > 1)
                    global.fixedFunEvents = 0;
            }
        }
        else if (global.menuno == 26)
        {
            if (global.menucoord[26] == 0)
                listeningForKey = 16;
            
            if (global.menucoord[26] == 1)
                listeningForKey = 17;
            
            if (global.menucoord[26] == 2)
                listeningForKey = 20;
        }
    }
    
    comment = "Split menu controls";
    
    if (addSplit && global.textInputState)
    {
        selection = global.menucoord[22];
        
        for (i = 0; i < 9; i++)
            tempRooms[i] = obj_time.segmentRooms[i];
        
        i = selection + 1;
        
        while (i < 9)
        {
            tempRooms[i] = obj_time.segmentRooms[i - 1];
            i++;
        }
        
        if (tempRooms[selection] == -1)
            tempRooms[selection] = global.lastEnteredValue;
        else
            tempRooms[selection + 1] = global.lastEnteredValue;
        
        for (i = 0; i < 9; i++)
            obj_time.segmentRooms[i] = tempRooms[i];
        
        addSplit = 0;
    }
    
    if (global.menuno == 22 && obj_time.currentSegment == 0 && obj_time.timerActive == 0)
    {
        if (keyboard_check_pressed(vk_insert))
        {
            if (obj_time.segmentRooms[8] == -1)
                prompt("Room name or ID: ", global.currentroom, "splitroom");
            else
                snd_play(snd_swallow);
            
            addSplit = 1;
        }
        
        if (keyboard_check_pressed(vk_delete))
        {
            selection = global.menucoord[22];
            
            if (obj_time.segmentRooms[selection] != -1)
            {
                for (i = selection; i < 9; i++)
                    obj_time.segmentRooms[i] = obj_time.segmentRooms[i + 1];
                
                if (obj_time.segmentRooms[selection] == -1 && selection > 0)
                    global.menucoord[22]--;
                
                snd_play(snd_swallow);
            }
        }
        
        if (keyboard_check(vk_shift))
        {
            selection = global.menucoord[22];
            
            if (keyboard_check_pressed(vk_up) && selection > 0)
            {
                first = obj_time.segmentRooms[selection];
                second = obj_time.segmentRooms[selection - 1];
                obj_time.segmentRooms[selection] = second;
                obj_time.segmentRooms[selection - 1] = first;
                snd_play(snd_swallow);
            }
            
            if (keyboard_check_pressed(vk_down) && selection < 9 && obj_time.segmentRooms[selection + 1] != -1)
            {
                first = obj_time.segmentRooms[selection];
                second = obj_time.segmentRooms[selection + 1];
                obj_time.segmentRooms[selection] = second;
                obj_time.segmentRooms[selection + 1] = first;
                snd_play(snd_swallow);
            }
        }
    }
    
    if (!global.textInputActive && !myTextboxIsOpen)
    {
        global.textInputState = 0;
        
        if (keyboard_check_pressed(vk_up))
        {
            debugoffsety--;
            
            if (global.menuno == 0)
            {
                if (global.menucoord[0] != 0)
                    global.menucoord[0] -= 1;
            }
            
            if (global.menuno == 1)
            {
                if (global.menucoord[1] != 0)
                    global.menucoord[1] -= 1;
            }
            
            if (global.menuno == 3)
            {
                if (global.menucoord[3] != 0)
                    global.menucoord[3] -= 1;
            }
            
            if (global.menuno == 6)
            {
                if (global.menucoord[6] != 0)
                    global.menucoord[6] -= 1;
            }
            
            if (global.menuno == 7)
            {
                if (global.menucoord[7] != 0)
                    global.menucoord[7] -= 1;
            }
            
            if (global.menuno == 11)
            {
                if (global.menucoord[11] != 0)
                    global.menucoord[11] -= 1;
            }
            
            if (global.menuno == 12)
            {
                if (global.menucoord[12] != 0)
                    global.menucoord[12] -= 1;
            }
            
            if (global.menuno == 13)
            {
                if (global.menucoord[13] != 0)
                    global.menucoord[13] -= 1;
            }
            
            if (global.menuno == 14)
            {
                if (global.menucoord[14] != 0)
                    global.menucoord[14] -= 1;
            }
            
            if (global.menuno == 15)
            {
                if (global.menucoord[15] != 0 && global.menucoord[15] != 9 && global.menucoord[15] != 19)
                    global.menucoord[15] -= 1;
            }
            
            if (global.menuno == 16)
            {
                if (global.menucoord[16] != 0 && global.menucoord[16] != 11 && global.menucoord[16] != 22)
                    global.menucoord[16] -= 1;
            }
            
            if (global.menuno == 17)
            {
                if (global.menucoord[17] != 0)
                    global.menucoord[17] -= 1;
            }
            
            if (global.menuno == 18)
            {
                if (global.menucoord[18] != 0)
                    global.menucoord[18] -= 1;
            }
            
            if (global.menuno == 19)
            {
                if (global.menucoord[19] != 0)
                    global.menucoord[19] -= 1;
            }
            
            if (global.menuno == 20)
            {
                if (global.menucoord[20] != 0)
                    global.menucoord[20] -= 1;
            }
            
            if (global.menuno == 21)
            {
                if (global.menucoord[21] != 0)
                    global.menucoord[21] -= 1;
            }
            
            if (global.menuno == 22)
            {
                if (global.menucoord[22] != 0)
                    global.menucoord[22] -= 1;
            }
            
            if (global.menuno == 23)
            {
                if (global.menucoord[23] != 0)
                    global.menucoord[23] -= 1;
            }
            
            if (global.menuno == 24)
            {
                if (global.menucoord[24] != 0)
                    global.menucoord[24] -= 1;
            }
            
            if (global.menuno == 25)
            {
                if ((debugOptionPage == 0 && global.menucoord[25] != 0) || (debugOptionPage == 1 && global.menucoord[25] != 9))
                    global.menucoord[25] -= 1;
            }
            
            if (global.menuno == 26)
            {
                if (global.menucoord[26] != 0)
                    global.menucoord[26] -= 1;
            }
        }
        
        if (keyboard_check_pressed(vk_down))
        {
            debugoffsety++;
            
            if (global.menuno == 0)
            {
                if (global.menucoord[0] != 2)
                {
                    if (global.menuchoice[global.menucoord[0] + 1] != 0)
                        global.menucoord[0] += 1;
                }
            }
            
            if (global.menuno == 1)
            {
                if (global.menucoord[1] != 7)
                {
                    if (global.item[global.menucoord[1] + 1] != 0)
                        global.menucoord[1] += 1;
                }
            }
            
            if (global.menuno == 3)
            {
                if (global.menucoord[3] != 7)
                {
                    if (global.phone[global.menucoord[3] + 1] != 0)
                        global.menucoord[3] += 1;
                }
            }
            
            if (global.menuno == 6)
            {
                if (global.menucoord[6] != 7)
                {
                    if (global.item[global.menucoord[6] + 1] != 0)
                        global.menucoord[6] += 1;
                }
            }
            
            if (global.menuno == 7)
            {
                if (global.menucoord[7] != 9)
                {
                    if (global.flag[global.menucoord[7] + 301] != 0)
                        global.menucoord[7] += 1;
                }
            }
            
            if (global.menuno == 11)
            {
                if (obj_time.timerEnable)
                    menuOptions = 4;
                else
                    menuOptions = 2;
                
                if (global.menucoord[11] != global.menulength[11])
                    global.menucoord[11] += 1;
            }
            
            if (global.menuno == 12)
            {
                if (global.menucoord[12] != global.menulength[12])
                    global.menucoord[12] += 1;
            }
            
            if (global.menuno == 13)
            {
                if (global.menucoord[13] != global.menulength[13])
                    global.menucoord[13] += 1;
            }
            
            if (global.menuno == 14)
            {
                if (global.menucoord[14] != global.menulength[14])
                    global.menucoord[14] += 1;
            }
            
            if (global.menuno == 15)
            {
                if (global.menucoord[15] != global.menulength[15])
                {
                    if (global.menucoord[15] != 18)
                    {
                        if (global.menucoord[15] != 25)
                            global.menucoord[15] += 1;
                    }
                }
            }
            
            if (global.menuno == 16)
            {
                if (global.menucoord[16] != 10 && global.menucoord[16] != 21 && global.menucoord[16] != 32)
                    global.menucoord[16] += 1;
            }
            
            if (global.menuno == 17)
            {
                if (global.menucoord[17] != global.menulength[17])
                    global.menucoord[17] += 1;
            }
            
            if (global.menuno == 18)
            {
                if (global.menucoord[18] != global.menulength[18])
                    global.menucoord[18] += 1;
            }
            
            if (global.menuno == 19)
            {
                if (global.menucoord[19] != global.menulength[19])
                    global.menucoord[19] += 1;
            }
            
            if (global.menuno == 20)
            {
                if (global.menucoord[20] != global.menulength[20])
                    global.menucoord[20] += 1;
            }
            
            if (global.menuno == 21)
            {
                if (global.menucoord[21] != global.menulength[21])
                    global.menucoord[21] += 1;
            }
            
            if (global.menuno == 22)
            {
                if (global.menucoord[22] != global.menulength[22])
                    global.menucoord[22] += 1;
            }
            
            if (global.menuno == 23)
            {
                if (global.menucoord[23] != global.menulength[23])
                    global.menucoord[23] += 1;
            }
            
            if (global.menuno == 24)
            {
                if (global.menucoord[24] != global.menulength[24])
                    global.menucoord[24] += 1;
            }
            
            if (global.menuno == 25)
            {
                if (global.menucoord[25] != global.menulength[25])
                    global.menucoord[25] += 1;
            }
            
            if (global.menuno == 26)
            {
                if (global.menucoord[26] != global.menulength[26])
                    global.menucoord[26] += 1;
            }
        }
        
        if (keyboard_multicheck_pressed(16) && buffer >= 0)
        {
            if (global.menuno == 0 || global.menuno == 10)
            {
                savePracticeOptions();
                global.menuno = -1;
                global.interact = 0;
            }
            else if (global.menuno <= 3)
            {
                global.menuno = 0;
            }
            else if (global.menuno == 5)
            {
                global.menuno = 1;
            }
            else if (global.menuno > 10 && global.menuno < 15)
            {
                global.menuno = 10;
            }
            else if (global.menuno == 15 || global.menuno == 16)
            {
                global.menuno = 13;
            }
            else if (global.menuno == 17)
            {
                global.menuno = 19;
            }
            else if (global.menuno == 18)
            {
                global.menuno = 11;
            }
            else if (global.menuno == 19)
            {
                global.menuno = 10;
            }
            else if (global.menuno == 20)
            {
                global.menuno = 14;
            }
            else if (global.menuno == 21 || (global.menuno == 22 && !keyboard_check_pressed(vk_shift)) || global.menuno == 23 || global.menuno == 24)
            {
                global.menuno = 19;
            }
            else if (global.menuno == 25 || global.menuno == 26)
            {
                global.menuno = 11;
            }
        }
        
        if (keyboard_check_pressed(vk_right))
        {
            debugoffsetx++;
            
            if (global.menuno == 5)
            {
                if (global.menucoord[5] != 2)
                    global.menucoord[5] += 1;
            }
            
            if (global.menuno == 10)
            {
                if (global.menucoord[10] != 4)
                    global.menucoord[10] += 1;
                else
                    global.menucoord[10] = 0;
            }
            
            if (global.menuno == 13)
            {
                if (global.menucoord[13] != 1)
                    global.menucoord[13] += 1;
                else
                    global.menucoord[13] = 0;
            }
            
            if (global.menuno == 14)
            {
                if (global.menucoord[14] == 5)
                {
                    if (global.fixedblcon < 5 && global.fixedblcon > -1)
                        global.fixedblcon++;
                }
            }
            
            if (global.menuno == 15)
            {
                if (global.menucoord[15] <= 8)
                {
                    global.menucoord[15] += 9;
                }
                else if (global.menucoord[15] > 8 && global.menucoord[15] <= 19)
                {
                    if (global.menucoord[15] <= 15)
                        global.menucoord[15] += 10;
                }
            }
            
            if (global.menuno == 16)
            {
                if ((global.menucoord[16] + 11) <= 32)
                    global.menucoord[16] += 11;
            }
            
            if (global.menuno == 25)
            {
                if (debugOptionPage == 0)
                {
                    debugOptionPage = 1;
                    global.menucoord[25] = 9;
                }
                else
                {
                    debugOptionPage = 0;
                    global.menucoord[25] = 0;
                }
            }
        }
        
        if (keyboard_check(vk_right))
        {
            if (global.menuno == 23 && (DAS == 0 || DAS > 15))
            {
                if (global.menucoord[23] == 0)
                {
                    if (obj_time.primaryScale < 2)
                        obj_time.primaryScale += 0.01;
                }
                
                if (global.menucoord[23] == 1)
                {
                    if (obj_time.secondaryScale < obj_time.primaryScale)
                        obj_time.secondaryScale += 0.01;
                }
                
                if (global.menucoord[23] == 2)
                {
                    if (obj_time.splitsScale < 2)
                        obj_time.splitsScale += 0.01;
                }
                
                if (global.menucoord[23] == 6)
                {
                    if (obj_time.timerBgAlpha < 1)
                        obj_time.timerBgAlpha += 0.01;
                }
                
                if (DAS == 0)
                    confirm = 1;
            }
            
            DAS++;
        }
        
        if (keyboard_check_pressed(vk_left))
        {
            debugoffsetx--;
            
            if (global.menuno == 5)
            {
                if (global.menucoord[5] != 0)
                    global.menucoord[5] -= 1;
            }
            
            if (global.menuno == 10)
            {
                if (global.menucoord[10] != 0)
                    global.menucoord[10] -= 1;
                else
                    global.menucoord[10] = 4;
            }
            
            if (global.menuno == 13)
            {
                if (global.menucoord[13] != 0)
                    global.menucoord[13] -= 1;
                else
                    global.menucoord[13] = 1;
            }
            
            if (global.menuno == 14)
            {
                if (global.menucoord[14] == 5)
                {
                    if (global.fixedblcon > -1)
                        global.fixedblcon--;
                }
            }
            
            if (global.menuno == 15)
            {
                if (global.menucoord[15] > 18)
                    global.menucoord[15] -= 10;
                else if (global.menucoord[15] > 8 && global.menucoord[15] <= 17)
                    global.menucoord[15] -= 9;
            }
            
            if (global.menuno == 16)
            {
                if ((global.menucoord[16] - 11) >= 0)
                    global.menucoord[16] -= 11;
            }
            
            if (global.menuno == 25)
            {
                if (debugOptionPage == 0)
                {
                    debugOptionPage = 1;
                    global.menucoord[25] = 9;
                }
                else
                {
                    debugOptionPage = 0;
                    global.menucoord[25] = 0;
                }
            }
        }
        
        if (keyboard_check(vk_left))
        {
            if (global.menuno == 23 && (DAS == 0 || DAS > 15))
            {
                if (global.menucoord[23] == 0)
                {
                    if (obj_time.primaryScale > 0.5)
                        obj_time.primaryScale -= 0.01;
                }
                
                if (global.menucoord[23] == 1)
                {
                    if (obj_time.secondaryScale > 0.5)
                        obj_time.secondaryScale -= 0.01;
                }
                
                if (global.menucoord[23] == 2)
                {
                    if (obj_time.splitsScale > 0.5)
                        obj_time.splitsScale -= 0.01;
                }
                
                if (global.menucoord[23] == 6)
                {
                    if (obj_time.timerBgAlpha > 0)
                        obj_time.timerBgAlpha -= 0.01;
                }
                
                if (DAS == 0)
                    confirm = 1;
            }
            
            DAS++;
        }
        
        if (!keyboard_check(vk_left) && !keyboard_check(vk_right))
            DAS = 0;
        
        if (keyboard_multicheck_pressed(17))
        {
            if (global.menuno == 0)
            {
                global.menuno = -1;
                global.interact = 0;
            }
        }
        
        if (keyboard_check_pressed(ord("C")))
        {
            if (global.menuno >= 10 && global.menuno < 99)
            {
                savePracticeOptions();
                global.menuno = -1;
                global.interact = 0;
            }
        }
        
        if (keyboard_check_pressed(ord("M")) && global.menuno == 10)
        {
            savePracticeOptions();
            global.menuno = -1;
            global.interact = 0;
        }
    }
    
    comment = "Play sound effects";
    
    if (isCustomMenu)
    {
        if (currentmenu == global.menuno && currentspot != global.menucoord[global.menuno] && !keyboard_check(vk_shift))
            snd_play(snd_squeak);
        
        if (confirm)
            caster_play(confirmSound, confirmSoundVolume, confirmSoundPitch);
        
        if (global.menuno < currentmenu && global.menuno >= 0 && global.menuno != 9)
            snd_play(snd_swallow);
    }
    else if (currentmenu < global.menuno && global.menuno != 9)
    {
        snd_play(snd_select);
    }
    else if (global.menuno >= 0 && global.menuno < 6)
    {
        if (currentspot != global.menucoord[global.menuno])
            snd_play(snd_squeak);
    }
}

if (global.menuno == 9 && instance_exists(obj_dialoguer) == 0)
{
    global.menuno = -1;
    global.interact = 0;
}
