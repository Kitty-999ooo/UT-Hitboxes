image_index = 0;
image_speed = 0;
shake = 0;
top = bbox_top;
bottom = bbox_bottom;
left = bbox_left;
right = bbox_right;
color = "interact";
