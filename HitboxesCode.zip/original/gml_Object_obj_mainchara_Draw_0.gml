if (inwater == 0)
    draw_sprite_ext(sprite_index, image_index, x, y, 1, 1, image_angle, image_blend, image_alpha);

if (inwater == 1)
{
    draw_sprite_part_ext(sprite_index, image_index, 0, 0, sprite_width, sprite_height - 5, x, y + 5, 1, 1, c_white, image_alpha);
    
    if (obj_mainchara.image_index == 1 || obj_mainchara.image_index == 3)
    {
        snd_play(snd_splash);
        mp = 0;
    }
    
    draw_sprite(spr_waterripple, 0, x, y);
}

if (room == room_water_waterfall3)
    draw_sprite_ext(sprite_index, image_index, x, y, 1, 1, image_angle, c_black, image_alpha);

if (sprite_index == dsprite)
    bbox_create("interact", bbox_left, bbox_bottom, bbox_right, bbox_bottom + 12, 1, 0);

if (sprite_index == usprite)
    bbox_create("interact", bbox_left, bbox_top - 9, bbox_right, bbox_top, 1, 0);

if (sprite_index == rsprite)
    bbox_create("interact", bbox_right, bbox_top, bbox_right + 12, bbox_bottom, 1, 0);

if (sprite_index == lsprite)
    bbox_create("interact", bbox_left - 12, bbox_top, bbox_left, bbox_bottom, 1, 0);

bbox_create("player", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
bbox_create("floorint", bbox_left + 6, bbox_top + 3, bbox_right - 6, bbox_bottom + 1, 0, 0);
