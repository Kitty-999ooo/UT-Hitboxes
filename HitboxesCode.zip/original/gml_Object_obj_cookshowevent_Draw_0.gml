if (con < 4)
{
    depth = obj_mainchara.depth + 1000;
    draw_set_color(c_black);
    draw_rectangle(-1, -1, 400, 500, false);
}

bbox_create("trigger", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
