if (image_alpha < 1)
    image_alpha += 0.05;

draw_self_border_ext(1, 1, 16777215, image_alpha);
bbox_create("white", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
