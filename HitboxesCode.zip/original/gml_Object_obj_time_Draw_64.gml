display_set_gui_size(view_wport[0], view_hport[0]);
xx = view_xview[view_current];
yy = view_yview[view_current];
draw_set_font(fnt_maintext);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
comment = "--Code for +500G key--";

if (goldtext > 0)
{
    draw_set_color(c_yellow);
    draw_text_color(5, 30 - goldtext, "+" + string(goldamount), c_yellow, c_yellow, c_yellow, c_yellow, 1 * (goldtext / 30));
    goldtext--;
}

if (keyboard_check_pressed(vk_f7) && global.debug)
{
    global.gold += 500;
    goldamount = 500;
    goldtext = 30;
    snd_play(snd_dumbvictory);
}

comment = "--Code for savestate functionality--";
draw_set_color(c_white);
savestateText = "";
input = 0;

if (!(room == room_settings))
{
    if (keyboard_check(global.keybindStateslot) && global.savestates >= 1)
    {
        for (i = 48; i < 58; i++)
        {
            if (keyboard_check_pressed(i))
            {
                savestateSlot = i - 48;
                ini_open("PracticeDataTemp.ini");
                ini_write_real("choice", "state", savestateSlot);
                ini_close();
            }
        }
        
        savestateText += ("Savestate slot: " + string(savestateSlot) + "#");
        savestateTextTimer = 5;
    }
    
    if (keyboard_check(global.keybindSaveSlot) && global.debug)
    {
        for (i = 48; i < 56; i++)
        {
            if (keyboard_check_pressed(i))
            {
                global.filechoice = i - 48;
                ini_open("PracticeDataTemp.ini");
                ini_write_real("choice", "file", global.filechoice);
                ini_close();
            }
        }
        
        savestateText += ("Save file slot: " + string(global.filechoice) + "#");
        savestateTextTimer = 5;
    }
    
    if (keyboard_check_pressed(global.keybindSavestate) && global.savestates == 2)
    {
        if (caster_is_playing(global.currentsong))
        {
            musicSave = 1;
            musicPlaying = global.currentsong;
            musicPitch = caster_get_pitch(global.currentsong);
            musicVolume = caster_get_volume(global.currentsong);
            musicPos = audio_sound_get_track_position(global.currentsongi);
        }
        else
        {
            musicSave = 0;
        }
        
        if (caster_is_playing(global.batmusic))
        {
            musicSaveB = 1;
            musicPlaying = global.batmusic;
            musicPitch = caster_get_pitch(global.batmusic);
            musicVolume = caster_get_volume(global.batmusic);
            musicPos = audio_sound_get_track_position(global.batmusici);
        }
        else
        {
            musicSaveB = 0;
        }
        
        if (timerActive)
            timerSaved = get_timer() + 33333.333333333336;
        else
            timerSaved = 0;
        
        savestateSegment = currentSegment;
        file_copy("undertale.ini", "save" + string(savestateSlot) + "_ini");
        alarm[0] = 1;
        game_save("save" + string(savestateSlot) + "_" + global.modVersion);
        alarm[0] = -2;
    }
    
    if (fileErrorTimer)
    {
        savestateText += ("File " + string(fileError) + " doesn't exist.");
        fileErrorTimer--;
    }
    
    if (keyboard_check_pressed(global.keybindLoadstate) && global.savestates >= 1 && !keyboard_check(ord("6")))
    {
        ini_open("PracticeDataTemp.ini");
        savestateSlot = ini_read_real("choice", "state", 0);
        ini_close();
        
        if (file_exists("save" + string(savestateSlot) + "_" + global.modVersion))
        {
            game_load("save" + string(savestateSlot) + "_" + global.modVersion);
        }
        else
        {
            savestateError = string(savestateSlot);
            savestateErrorTimer = 20;
        }
    }
    
    if (savestateErrorTimer > 0)
    {
        savestateText += ("Savestate " + string(savestateSlot) + " doesn't exist, or is from an older version.");
        savestateErrorTimer--;
    }
    
    draw_set_color(c_white);
    draw_set_halign(fa_center);
    draw_text(320, 0, savestateText);
    draw_set_halign(fa_left);
    comment = "--Timer Code--";
    
    if (timerActive)
    {
        runningTimer = get_timer() - runningTimerStart - timerLoaded;
        
        if (savestateSegment == currentSegment)
            segmentTimer = get_timer() - segmentTimerStart - timerLoaded;
        else
            segmentTimer = get_timer() - segmentTimerStart;
    }
}

if (currentroom != room)
{
    if (room == floor(segmentRooms[currentSegment]))
    {
        if (floor(segmentRooms[currentSegment]) == segmentRooms[currentSegment])
        {
            split = 1;
        }
        else
        {
            entrance = (segmentRooms[currentSegment] - floor(segmentRooms[currentSegment])) * 100;
            
            if (global.entrance == entrance)
                split = 1;
        }
    }
    
    if (timerActive)
    {
        roomTimer = runningTimer;
        segmentRoomTimer = segmentTimer;
    }
}

if (segmentRooms[currentSegment] < -1)
{
    object = abs(ceil(segmentRooms[currentSegment]));
    cutscene = abs(segmentRooms[currentSegment] - ceil(segmentRooms[currentSegment])) * 100;
    
    if (instance_exists(object))
    {
        if (object.con == cutscene)
            split = 1;
    }
}

if (global.menuno < 10)
{
    if (keyboard_check_pressed(keybindTimerSplit))
        split = 1;
    
    if (keyboard_check_pressed(keybindTimerReset))
        reset = 1;
    
    if (keyboard_check_pressed(keybindTimerUndo))
    {
        if (currentSegment > 0)
        {
            currentSegment--;
            segmentTimerStart -= segmentTimes[currentSegment];
            segmentTimes[currentSegment] = 0;
            splitTimes[currentSegment] = 0;
            
            if (!timerActive)
                timerActive = 1;
        }
    }
    
    if (keyboard_check_pressed(keybindTimerSkip))
    {
        if (timerActive && segmentRooms[currentSegment + 1] != -1)
        {
            segmentTimes[currentSegment] = -2;
            currentSegment++;
        }
    }
    
    if (keyboard_check_pressed(keybindTimerToggleSplits))
    {
        splitsVisible++;
        
        if (splitsVisible > 1)
            splitsVisible = 0;
    }
}

if (split)
{
    if (!timerActive && runningTimer == 0)
    {
        segmentTimes[currentSegment] = get_timer();
        runningTimerStart = get_timer();
        segmentTimerStart = get_timer();
        timerActive = 1;
        currentSegment = 1;
    }
    else if (!timerActive && runningTimer > 0)
    {
        reset = 1;
    }
    else
    {
        segmentTimes[currentSegment] = segmentTimer;
        splitTimes[currentSegment] = runningTimer;
        segmentTimerStart = get_timer();
        currentSegment++;
        
        if (segmentRooms[currentSegment] == -1)
            timerActive = 0;
    }
    
    split = 0;
}

if (reset)
{
    if (timerActive || runningTimer > 0)
    {
        runningTimer = 0;
        roomTimer = 0;
        segmentTimer = 0;
        segmentRoomTimer = 0;
        timerActive = 0;
        currentSegment = 0;
        timerLoaded = 0;
        timerSaved = 0;
        
        for (i = 1; i < 11; i++)
        {
            if (segmentRooms[i] != -1)
            {
                segmentTimes[i] = 0;
                splitTimes[i] = 0;
            }
        }
    }
    
    reset = 0;
}

comment = "--Draw Timer--";

if (primaryUpdate == 0)
{
    if (primaryTiming == 0)
        primaryTimer = createTimerText(runningTimer, 1);
    else if (primaryTiming == 1)
        primaryTimer = createTimerText(segmentTimer, 1);
}
else if (primaryUpdate == 1)
{
    if (primaryTiming == 0)
        primaryTimer = createTimerText(roomTimer, 1);
    else if (primaryTiming == 1)
        primaryTimer = createTimerText(segmentRoomTimer, 1);
}

if (secondaryUpdate == 0)
{
    if (secondaryTiming == 0)
        secondaryTimer = createTimerText(runningTimer, 1);
    else if (secondaryTiming == 1)
        secondaryTimer = createTimerText(segmentTimer, 1);
}
else if (secondaryUpdate == 1)
{
    if (secondaryTiming == 0)
        secondaryTimer = createTimerText(roomTimer, 1);
    else if (secondaryTiming == 1)
        secondaryTimer = createTimerText(segmentRoomTimer, 1);
}

if (timerEnable)
{
    draw_set_font(timerFont);
    borderX = string_width(primaryTimer) * primaryScale;
    borderX += (2 * primaryScale);
    borderY = (string_height(primaryTimer) * primaryScale) + (string_height(secondaryTimer) * secondaryScale);
    
    if (timerLoaded > 0)
        draw_set_color(merge_color(c_green, c_black, 0.5));
    else
        draw_set_color(c_black);
    
    draw_set_alpha(timerBgAlpha);
    draw_rectangle(0, 0, borderX, borderY, false);
    
    if (timerShowRoom)
        draw_text_transformed(2 * global.timerSize, 23 * global.timerSize, string(room), global.timerSize, global.timerSize, 0);
    
    draw_set_color(c_white);
    draw_set_alpha(1);
    draw_text_transformed(2 * primaryScale, 0, primaryTimer, primaryScale, primaryScale, 0);
    draw_set_color(c_gray);
    
    if (secondaryScale > primaryScale)
        secondaryScale = primaryScale;
    
    draw_text_transformed(2 * secondaryScale, string_height(primaryTimer) * primaryScale, secondaryTimer, secondaryScale, secondaryScale, 0);
    segmentText = "";
    i = 1;
    
    while (i < 9)
    {
        if (segmentRooms[i] == -1)
        {
            break;
        }
        else
        {
            if (splitsDisplayMode < 2)
            {
                if (segmentTimes[i] == -2)
                    segmentText += "-:--.--";
                else
                    segmentText += createTimerText(splitTimes[i]);
            }
            
            if (splitsDisplayMode == 0)
                segmentText += " | ";
            
            if (splitsDisplayMode == 0 || splitsDisplayMode == 2)
            {
                if (segmentTimes[i] == -2)
                    segmentText += "-:--.--";
                else
                    segmentText += createTimerText(segmentTimes[i]);
            }
            
            segmentText += "#";
            i++;
            continue;
        }
    }
    
    if (!splitsVisible)
        segmentText = "[Splits hidden]";
    
    if (i > 2)
    {
        draw_set_font(splitsFont);
        draw_set_halign(fa_right);
        draw_set_color(c_black);
        draw_set_alpha(timerBgAlpha);
        draw_rectangle(640 - (string_width(segmentText) * splitsScale) - 4, string_height(segmentText) * splitsScale, 640, 0, false);
        draw_set_color(c_white);
        draw_set_alpha(1);
        draw_text_transformed(640 - (2 * splitsScale), 0, segmentText, splitsScale, splitsScale, 0);
        draw_set_halign(fa_left);
    }
}

draw_set_font(fnt_maintext);
comment = "--Code for dummy practice mode--";

if (global.dummyPractice)
{
    if (global.dummyFrames > -100 && (room == room_battle || room == room_water_trashsavepoint))
    {
        dummyText = string(abs(global.dummyFrames));
        
        if (global.dummyFrames > 0)
        {
            dummyText += " frame";
            
            if (global.dummyFrames > 1)
                dummyText += "s";
            
            dummyText += " late.";
        }
        else if (global.dummyFrames < 0)
        {
            dummyText += " frame";
            
            if (global.dummyFrames < -1)
                dummyText += "s";
            
            dummyText += " early.";
        }
        else if (global.dummyFrames == 0)
        {
            dummyText += " frames off!";
            draw_set_color(c_yellow);
        }
        
        draw_text(0, 0, dummyText);
    }
    else if (global.dummyFrames == -100 && room == room_water_trashzone2)
    {
        draw_text(0, 0, "MDS practice mode enabled.");
    }
}

comment = "--Misc stuff--";

if (keyboard_check(ord("6")) && global.menuno == -1 && !keyboard_check(ord("O")) && !keyboard_check(ord("P")) && room != room_battle && global.debug)
{
    draw_set_halign(fa_center);
    draw_set_color(c_white);
    draw_text(320, 0, "Fast Teleport:#R - Ruins#T - Snowdin#W - Waterfall#F - Hotland#E - New Home#Y - True Lab");
    
    if (keyboard_check(ord("F")))
        room_goto(room_fire2);
    
    if (keyboard_check(ord("T")))
        room_goto(room_tundra1);
    
    if (keyboard_check(ord("W")))
        room_goto(room_water1);
    
    if (keyboard_check(ord("E")))
        room_goto(room_castle_front);
    
    if (keyboard_check(ord("R")))
        room_goto(room_ruins2);
    
    if (keyboard_check(ord("Y")))
        room_goto(room_truelab_elevator);
}

if (infoTimer > 0 && instance_exists(obj_mainchara))
{
    draw_set_halign(fa_right);
    draw_set_color(c_white);
    draw_text(640, 0, "Press M to open practice menu.#Hold 6 for Fast Teleport.");
    infoTimer--;
}

currentroom = room;
draw_set_halign(fa_left);

if (keyboard_check_pressed(vk_f11))
{
    if (!global.weaponPracticeMode)
    {
        debugInfo++;
        
        if (debugInfo > 1)
            debugInfo = 0;
    }
}

if (debugInfo)
{
    debugInfoText = "";
    debugInfoText += ("Room speed: " + string(room_speed) + "#");
    
    if (global.menuno != -1)
    {
        debugInfoText += ("Menuno: " + string(global.menuno) + "#");
        debugInfoText += ("Menucoord: " + string(global.menucoord[global.menuno]) + "#");
    }
    
    if (instance_exists(obj_undyneencounter4))
        debugInfoText += ("con: " + string(obj_undyneencounter4.con) + "#");
    
    debugInfoText += ("Room: " + room_get_name(room) + " (" + string(room) + ")" + "#");
    debugInfoText += ("Entrance: " + string(global.entrance) + "#");
    debugInfoText += ("Interact: " + string(global.interact) + "#");
    debugInfoText += ("Border: " + string(global.border) + "#");
    debugInfoText += ("Plot: " + string(global.plot) + "#");
    
    if (instance_exists(obj_mainchara))
        debugInfoText += ("X: " + string(obj_mainchara.x) + " | Y: " + string(obj_mainchara.y) + "#");
    else if (room == room_battle)
        debugInfoText += ("Battle ID: " + string(global.battlegroup) + "#");
    
    draw_set_color(c_black);
    draw_set_alpha(0.6);
    draw_rectangle(0, 478 - string_height(debugInfoText), string_width(debugInfoText) + 4, 480, false);
    draw_set_valign(fa_bottom);
    draw_set_color(c_white);
    draw_set_alpha(1);
    draw_text(2, 478, debugInfoText);
}

draw_set_valign(fa_top);
