bbox_create("trigger", 390, -10, 390, 90, 1, 0, "line", 1);
bbox_create("trigger", 280, -10, 280, 1000, 1, 0, "line", 1);
