draw = 0;

if (object_index == obj_solidrailing || object_index == obj_solidrailing2 || object_index == obj_solidrailing3)
    draw = 1;

bbox_create("solid", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, draw);
