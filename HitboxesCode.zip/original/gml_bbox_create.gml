color = argument0;
x1 = argument1;
y1 = argument2;
x2 = argument3;
y2 = argument4;
hollow = argument5;
drawself = argument6;

if (argument8 != undefined)
    thickness = argument8;
else
    thickness = 1;

originalcolor = draw_get_color();

if (drawself == 1 && sprite_index != -1)
    draw_self();

if (ds_map_find_value(global.bbox_toggles, "active") && ds_map_find_value(global.bbox_toggles, color))
{
    draw_set_color(HexstringToColor(ds_map_find_value(global.bbox_colors, color)));
    
    if (argument7 != undefined && argument7 == "line")
    {
        draw_line_width(x1, y1, x2, y2, thickness);
    }
    else if (argument7 != undefined && argument7 == "triangle")
    {
        if (argument8 == "sur")
            draw_triangle(x1, y1, x2, y1, x2, y2, hollow);
        else if (argument8 == "sul")
            draw_triangle(x1, y1, x2, y1, x1, y2, hollow);
        else if (argument8 == "sdr")
            draw_triangle(x2, y1, x1, y2, x2, y2, hollow);
        else if (argument8 == "sdl")
            draw_triangle(x1, y1, x1, y2, x2, y2, hollow);
        else
            exit;
    }
    else
    {
        draw_rectangle(x1, y1, x2, y2, hollow);
    }
    
    draw_set_color(originalcolor);
}
