draw_self();

if (lit == 0 && active)
    bbox_create("trigger", bbox_left, -10, bbox_right + 16, 625, 1, 0);
