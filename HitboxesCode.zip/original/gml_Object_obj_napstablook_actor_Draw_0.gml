draw_sprite_ext(sprite_index, image_index, x, y, image_xscale, image_yscale, 0, c_white, image_alpha);

if (fun == 0)
    script_execute(scr_npcdir, 2);

scr_depth();
bbox_create("solid", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
bbox_create("interact", bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 0);
