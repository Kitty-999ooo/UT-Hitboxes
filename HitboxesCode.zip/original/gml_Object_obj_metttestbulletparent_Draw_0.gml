draw_self();

if (object_index != obj_mettfodder)
    bbox_create("white", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
