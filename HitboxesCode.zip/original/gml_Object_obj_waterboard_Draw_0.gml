draw_self();
fornow = "draw_sprite_ext(spr_interactable, 0, bbox_left, bbox_top, 1, 1, 0, c_white, 1)";
