draw_sprite_ext(spr_bullet_testx_arrow, image_index, x, y, 1, 1, 0, c_white, image_alpha);
bbox_create("white", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
