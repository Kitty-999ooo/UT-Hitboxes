if (type == 1)
    image_alpha -= 0.04;

if (image_alpha < 0.08)
    instance_destroy();

draw_sprite_ext(sprite_index, image_index, x, y, 1, 1, image_angle, c_white, image_alpha);

if (con == 999999)
{
    if (con > 0 && con < 3)
    {
        image_alpha -= 0.02;
        draw_set_color(c_black);
        draw_rectangle(200, 150, 500, 240, false);
        draw_set_color(c_white);
        draw_set_font(fnt_maintext_2);
        draw_text_transformed(200, 180, "You called for help...", 2, 2, 0);
    }
    
    if (con == 2)
    {
        type = 1;
        
        with (obj_6book_wordbullet)
            event_user(5);
        
        con = 2.1;
        alarm[4] = 50;
    }
    
    if (con == 3.1)
    {
        with (obj_6book_wordbullet)
            event_user(4);
        
        con = 3;
    }
}

if (image_alpha > 0.08)
{
    half_width = (right - left) / 2;
    half_height = (bottom - top) / 2;
    top_left_x = -half_width;
    top_left_y = -half_height;
    bottom_right_x = half_width;
    bottom_right_y = half_height;
    matrix_set(2, matrix_build(x, y, 0, 0, 0, image_angle, 1, 1, 1));
    bbox_create(color, top_left_x, top_left_y, bottom_right_x, bottom_right_y, 1, 0);
    matrix_set(2, matrix_build(0, 0, 0, 0, 0, 0, 1, 1, 1));
}
