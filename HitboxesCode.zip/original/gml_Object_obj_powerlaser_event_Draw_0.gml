if (drawblack == 1)
{
    draw_set_alpha(0.5);
    draw_set_color(c_black);
    draw_rectangle(-10, -10, room_width + 10, room_height + 10, false);
    draw_set_alpha(1);
}

bbox_create("trigger", 220, -10, 220, 250, 1, 0);
bbox_create("trigger", 600, -10, 600, 250, 1, 0);
bbox_create("trigger", 1060, -10, 1060, 250, 1, 0);
