draw_sprite(sprite_index, image_index, x, y);
draw_sprite(spr_book, image_index, x + 6, y + 1);
bbox_create("interact", bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 0);
