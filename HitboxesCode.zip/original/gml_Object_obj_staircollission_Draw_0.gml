if (ds_map_find_value(global.bbox_toggles, "active") && ds_map_find_value(global.bbox_toggles, "solid"))
{
    image_blend = HexstringToColor(ds_map_find_value(global.bbox_colors, "solid"));
    draw_self();
}
