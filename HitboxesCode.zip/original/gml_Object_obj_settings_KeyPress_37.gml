if (!input)
    menu = !menu;
