bbox_create("trigger", bbox_right + 1, -10, bbox_right + 1, 300, 1, 0);
