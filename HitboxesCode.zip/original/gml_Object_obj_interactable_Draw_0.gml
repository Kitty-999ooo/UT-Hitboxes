bbox_create("interact", bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 1);

if (room == room_fire_core4)
    bbox_create("trigger", 560, -10, 560, 1000, 1, 0);
