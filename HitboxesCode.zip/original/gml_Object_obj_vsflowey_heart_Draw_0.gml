draw_sprite(sprite_index, image_index, x, y);
bbox_create("player", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
