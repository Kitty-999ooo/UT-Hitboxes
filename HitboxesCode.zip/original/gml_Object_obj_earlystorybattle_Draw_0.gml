if (room == room_asghouse2 && con == 0 && global.flag[450] <= 2 && global.flag[455] == 0)
    cx = 69;

if (room == room_asghouse2 && con < 2 && global.flag[450] <= 2 && global.flag[455] == 1 && global.flag[456] < 2)
    cx = 180;

if (room == room_asghouse3 && con == 0 && global.flag[450] <= 2 && global.flag[456] == 0)
    cx = 460;

if (room == room_asghouse3 && con < 2 && global.flag[450] <= 2 && global.flag[456] == 1 && global.flag[455] < 2)
    cx = 79;

bbox_create("trigger", cx + 20, 0, cx + 20, 250, 1, 0);
