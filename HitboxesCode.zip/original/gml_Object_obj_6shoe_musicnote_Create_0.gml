image_blend = c_lime;
siner = random(300);
image_xscale = 2;
image_yscale = 2;
obj_6parent.color = "green";
