draw_sprite(sprite_index, image_index, x, y);

if (side == 1)
{
    draw_set_color(c_white);
    draw_rectangle(x + 2 + sprite_width + 1, y + 6, x + 22 + sprite_width + 1, y + 28, false);
    bbox_create("white", x + 6 + sprite_width + 1, y + 10, x + 18 + sprite_width + 1, y + 24, 1, 0);
}

if (side == 2)
{
    draw_set_color(c_white);
    draw_rectangle((x + 2) - sprite_width - 1, y + 6, (x + 22) - sprite_width - 1, y + 28, false);
    bbox_create("white", (x + 6) - sprite_width - 1, y + 10, (x + 18) - sprite_width - 1, y + 24, 1, 0);
}

bbox_create("white", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
