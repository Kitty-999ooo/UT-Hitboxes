bbox_create("trigger", bbox_left - 10, 12, bbox_right, 855, 1, 0);
bbox_create("trigger", bbox_right, 0, bbox_right + 20, 1150, 1, 0);
