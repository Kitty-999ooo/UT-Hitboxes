if (input)
{
    i = 48;
    
    while (i <= 105)
    {
        key = i;
        
        if ((keyboard_lastkey > ord("F") && keyboard_lastkey < vk_numpad0) || string_length(hex) >= 8)
        {
            break;
        }
        else if (keyboard_lastkey == key)
        {
            hex += keyboard_lastchar;
            break;
        }
        else
        {
            i += 1;
            continue;
        }
    }
}
