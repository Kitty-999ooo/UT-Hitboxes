rectcolor = "white";

if (green == 1)
{
    rectcolor = "green";
    sprite_index = spr_carrotbullet_gr;
    
    if (instance_exists(obj_parsnik))
        sprite_index = spr_carrotbullet_snake_gr;
}

draw_self_border();
bbox_create(rectcolor, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
