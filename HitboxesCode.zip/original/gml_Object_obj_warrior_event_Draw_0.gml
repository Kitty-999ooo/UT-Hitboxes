bbox_create("trigger", 240, -10, 240, 250, 1, 0);
bbox_create("trigger", 380, -10, 380, 250, 1, 0);
bbox_create("trigger", 500, -10, 500, 250, 1, 0);
