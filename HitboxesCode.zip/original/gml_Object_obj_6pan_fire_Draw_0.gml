color = "white";

if (image_blend == c_lime)
    color = "green";

bbox_create(color, bbox_left, bbox_top, bbox_right, bbox_bottom + b, 1, 1);
