color = "white";
draw_self_border_ext(1, 1, 16777215, image_alpha);

if (part == 4 || deactivate == 1)
    color = "disabled";

bbox_create(color, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
