draw_sprite(sprite_index, image_index, x, y);
draw_sprite(spr_platerock, image_index, x + 5, y + 20);
visible = true;
bbox_create("solid", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
