bbox_create("white", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
