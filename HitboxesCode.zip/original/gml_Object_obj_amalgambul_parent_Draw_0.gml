color = "white";

if (object_index == obj_freakbullet && !(image_index >= 3 && image_index <= 8))
    color = "disabled";

bbox_create(color, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
