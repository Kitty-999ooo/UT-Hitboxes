bbox_create("trigger", bbox_left - 3, bbox_top, bbox_right - 3, bbox_bottom, 1, 0);
