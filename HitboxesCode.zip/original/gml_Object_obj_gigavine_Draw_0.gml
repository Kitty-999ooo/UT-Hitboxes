color = "white";

if (image_alpha <= 0.3 || active == 0)
    color = "disabled";

bbox_create(color, x - 8, y, (x + xxl) - 8, y + yyl, 1, 1, "line", 2);
bbox_create(color, x + 8, y, x + xxl + 8, y + yyl, 1, 0, "line", 2);
