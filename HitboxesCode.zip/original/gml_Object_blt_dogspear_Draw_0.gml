draw_self_border();

if (global.turntimer < 1)
{
    global.turntimer = -1;
    global.mnfight = 3;
    instance_destroy();
}

if (blue == 1)
    rectcolor = "blue";

if (blue == 0)
    rectcolor = "white";

bbox_create(rectcolor, bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);
