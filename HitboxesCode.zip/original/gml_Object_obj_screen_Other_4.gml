window_set_caption("UNDERTALE Practice Mod + hitboxes mod");

if (room == room_fire_operatest)
    window_set_caption("UNDERTALE Practice Mod + hitboxes mod: the Musical");
