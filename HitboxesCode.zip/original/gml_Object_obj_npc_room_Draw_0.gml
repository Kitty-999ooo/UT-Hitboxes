if (room == room_water_undynehouse)
{
    ld = 1;
    rd = 8;
}

bbox_create("solid", bbox_left + ld, bbox_top, bbox_right - rd, bbox_bottom, 1, 1);
bbox_create("interact", bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 0);

if (room == room_water_undyneyard)
{
    if (global.plot < 122)
    {
        d = 1;
    }
    else if (global.flag[354] < 2)
    {
        d = 1;
    }
    else if (global.flag[67] == 1)
    {
        d = 1;
    }
    else if (global.flag[88] < 4)
    {
        d = 1;
    }
    else if (global.flag[350] == 1)
    {
        d = 1;
    }
    else if (global.flag[350] == 2)
    {
        d = 1;
    }
    else if (global.flag[389] >= 2)
    {
        d = 1;
    }
    else if (global.kills > 0)
    {
        d = 1;
    }
    else
    {
        d = 0;
        
        if (obj_undynedate_outside.con == 38)
            bbox_create("trigger", -10, 210, 320, 210, 1, 0);
    }
}
