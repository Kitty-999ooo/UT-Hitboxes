bbox_create("interact", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 1);
bbox_create("trigger", obj_lborder.bbox_left, obj_lborder.bbox_top, obj_lborder.bbox_right, obj_lborder.bbox_bottom, 1, 0);
