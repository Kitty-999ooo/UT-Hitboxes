if (input && string_length(hex) > 2)
    hex = string_delete(hex, string_length(hex), 1);
