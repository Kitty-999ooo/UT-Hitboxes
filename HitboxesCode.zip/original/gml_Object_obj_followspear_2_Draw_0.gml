color = "white";
draw_sprite_ext(sprite_index, image_index, x, y, 1, 1, image_angle, c_white, image_alpha);

if (rotspeed == 1 || deactivate == 1)
    color = "disabled";

bbox_create(color, x - (xoff / 2), y - (yoff / 2), x + xoff, y + yoff, 1, 0, "line", 2);
