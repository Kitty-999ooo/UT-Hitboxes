if (sprite_index != spr_interactable)
    draw_self();

if (object_index != obj_readable_switch1 && object_index != obj_switchadvice1 && object_index != obj_switchadvice2 && object_index != obj_metteggs && object_index != obj_mettsugar && sprite_index != spr_interactable)
    bbox_create("solid", bbox_left, bbox_top, bbox_right, bbox_bottom, 1, 0);

if (!(room == room_water_undynehouse) || global.interact == 0)
    bbox_create("interact", bbox_left - 4, bbox_top - 4, bbox_right + 3, bbox_bottom + 2, 1, 0);
