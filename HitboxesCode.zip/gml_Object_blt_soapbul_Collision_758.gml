x -= hspeed;
hspeed = -hspeed;
