image_index = 0;
image_speed = 0;
visible = false;
type = 0;
con = 0;
