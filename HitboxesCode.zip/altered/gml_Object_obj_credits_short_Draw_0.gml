draw_set_color(c_white);
draw_set_font(fnt_maintext);

if (number == -1)
    draw_sprite_ext(sprite_index, image_index, x, y, 1, 1, rot, c_white, 1);

if (number == 0)
    draw_text_transformed(90, 90, "By Toby Fox", 2, 2, 0);

if (number == 1)
{
    draw_set_color(c_yellow);
    draw_text(86, 30, "Logo Design#Cutscene Artist#Overworld Artist+#Animator (Area 1,2,3)#Shop Artist (Area 2,3)#Tile Artist (Area 2)");
    draw_set_color(c_white);
    draw_text_transformed(40, 130, "Temmie Chang", 2, 2, 0);
}

if (number == 2)
{
    draw_set_color(c_yellow);
    draw_text(60, 34, "Tile Artist (Area3+4)#And Hypertester");
    draw_set_color(c_white);
    draw_text(90, 74, "Kenju");
    draw_set_color(c_yellow);
    draw_text(60, 104, "Main BG Artist");
    draw_set_color(c_white);
    draw_text(90, 124, "Merrigo");
    draw_set_color(c_yellow);
    draw_text(60, 154, "Assistant Monster Designer");
    draw_set_color(c_white);
    draw_text(90, 174, "Magnolia Porter");
}

if (number == 3)
{
    draw_set_color(c_yellow);
    draw_text(60, 24, "Extra Art and Testing");
    draw_set_color(c_white);
    draw_text(90, 44, "Gigi DG#Drak#Clairevoire");
    draw_set_color(c_yellow);
    draw_text(60, 104, "Misc. Art");
    draw_set_color(c_white);
    draw_text(90, 124, "Easynam (Tile Area 1)#Guzusuru (Asgore Spear Reveal)");
    draw_set_color(c_yellow);
    draw_text(60, 164, "Guest Monster Designs");
    draw_set_color(c_white);
    draw_text(90, 184, '"Muffet" - Michelle Czajkowski#"Woshua" - Inspired by OMOCAT');
}

if (number == 4)
{
    draw_set_color(c_yellow);
    draw_text(60, 20, "Photoshop#Flowey Battle Co-design");
    draw_set_color(c_white);
    draw_text(90, 55, "Everdraed");
    draw_set_color(c_yellow);
    draw_text(60, 95, "Programming Help");
    draw_set_color(c_white);
    draw_text(90, 115, "Flashygoodness#Leon Arnott");
    draw_set_color(c_yellow);
    draw_text(60, 165, "Other Monster Designs");
    draw_set_color(c_white);
    draw_text(90, 185, "Mike Reid#????????????");
}

if (number == 5)
{
    draw_set_color(c_yellow);
    draw_text(60, 24, "Guest NPC Concepts");
    draw_set_color(c_white);
    draw_text(90, 44, 'Mushroom "Ragel" - Alexander Sward#"Sam Byool" - Ahmed Almutawa#Bah! "Puzzle Guy" - Summer Wine#Stars..? "Loren" - Colin MacDougall#Comedian Dad - Braxton Harris');
    draw_set_color(c_yellow);
    draw_text(60, 135, "Guitar");
    draw_set_color(c_white);
    draw_text(90, 155, "Stephanie MacIntire");
    draw_set_color(c_yellow);
    draw_text(60, 185, "Bratty & Catty Help");
    draw_set_color(c_white);
    draw_text(90, 205, "IPGD");
}

if (won >= 1)
{
    if (keyboard_multicheck(0))
    {
        if (alarm[5] > 20)
            alarm[5] = 20;
    }
}
