myinteract = 0;
