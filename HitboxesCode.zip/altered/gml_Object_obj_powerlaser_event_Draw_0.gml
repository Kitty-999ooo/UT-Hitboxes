if (drawblack == 1)
{
    draw_set_alpha(0.5);
    draw_set_color(c_black);
    draw_rectangle(-10, -10, room_width + 10, room_height + 10, false);
    draw_set_alpha(1);
}
