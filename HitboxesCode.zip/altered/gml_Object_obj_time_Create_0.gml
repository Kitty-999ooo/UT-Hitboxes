up = 0;
down = 0;
left = 0;
right = 0;
quit = 0;
restart = 0;
try_up = 0;
try_down = 0;
try_left = 0;
try_right = 0;
canquit = 1;
h_skip = 0;
j_xpos = 0;
j_ypos = 0;
j_dir = 0;
j_fr = 0;
j_fl = 0;
j_fu = 0;
j_fd = 0;
j_fr_p = 0;
j_fl_p = 0;
j_fu_p = 0;
j_fd_p = 0;

for (i = 0; i < 12; i += 1)
{
    j_prev[i] = 0;
    j_on[i] = 0;
}

global.button0 = 2;
global.button1 = 1;
global.button2 = 4;
global.analog_sense = 0.15;
global.analog_sense_sense = 0.01;
global.joy_dir = 0;
ini_open("config.ini");
b0_i = ini_read_real("joypad1", "b0", -1);
b1_i = ini_read_real("joypad1", "b1", -1);
b2_i = ini_read_real("joypad1", "b2", -1);
as_i = ini_read_real("joypad1", "as", -1);
jd_i = ini_read_real("joypad1", "jd", -1);

if (b0_i >= 0)
    global.button0 = b0_i;

if (b1_i >= 0)
    global.button1 = b1_i;

if (b2_i >= 0)
    global.button2 = b2_i;

if (as_i >= 0)
    global.analog_sense = as_i;

if (jd_i >= 0)
    global.joy_dir = jd_i;

ini_close();
debug_r = 0;
debug_f = 0;
j1 = 0;
j2 = 0;
ja = 0;
j_ch = 0;
jt = 0;
spec_rtimer = 0;
initvalues = 0;
currentroom = room;
goldtext = 0;
goldamount = 0;
savestateSlot = 0;
loadstateSlot = 0;
savestateText = "";
savestateTextTimer = 0;
savestateError = 0;
savestateErrorTimer = 0;
fileError = 0;
fileErrorTimer = 0;
infoTimer = 90;
musicSave = 0;
global.timerSize = 1;
versionCheck = 0;
versionRequest = 0;
debugInfo = 0;
comment = "--IGT variables--";
split = 0;
reset = 0;
runningTimer = 0;
runningTimerStart = 0;
roomTimer = 0;
segmentTimer = 0;
segmentTimerStart = 0;
segmentRoomTimer = 0;
currentSegment = 0;

for (i = 0; i < 11; i++)
{
    segmentRooms[i] = -1;
    segmentTimes[i] = 0;
    splitTimes[i] = 0;
}

timerEnable = 1;
timerActive = 0;
timerStartIn = 0;
timerEndIn = 0;
timerShowRoom = 0;
timerEndExitElevator = 0;
timerSaved = 0;
timerLoaded = 0;
primaryTimer = "";
secondaryTimer = "";
primaryUpdate = 0;
secondaryUpdate = 0;
primaryTiming = 0;
secondaryTiming = 0;
primaryScale = 1.5;
secondaryScale = 1;
splitsScale = 1;
splitsDisplayMode = 0;
timerBgAlpha = 0.6;
timerFont = 2;
splitsFont = 2;
keybindTimerSplit = 32;
keybindTimerReset = 71;
keybindTimerSkip = 74;
keybindTimerUndo = 72;
keybindTimerToggleSplits = 0;
splitsVisible = 1;
savestateSegment = 0;
