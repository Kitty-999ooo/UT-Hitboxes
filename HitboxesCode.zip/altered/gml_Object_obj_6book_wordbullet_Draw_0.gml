counter += 1;
draw_set_font(fnt_maintext_2);
width = string_width(word);
factor = 100 / width;
draw_set_color(image_blend);
draw_text_transformed(x, y, word, factor, 4.2, 0);

if (hspeed > 0 && x > 405)
    instance_destroy();

if (hspeed < 0 && x < 120)
    instance_destroy();

if (type == 2)
{
    shake += 0.2;
    x += (random(shake) - random(shake));
    y += (random(shake) - random(shake));
}
