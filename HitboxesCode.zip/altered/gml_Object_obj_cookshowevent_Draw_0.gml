if (con < 4)
{
    depth = obj_mainchara.depth + 1000;
    draw_set_color(c_black);
    draw_rectangle(-1, -1, 400, 500, false);
}
