draw_sprite(sprite_index, image_index, x, y);

if (myinteract == 1 && global.interact == 0 && con == 0)
{
    global.interact = 1;
    con = 1;
}

if (con == 1)
{
    global.facechoice = 0;
    global.typer = 5;
    global.msc = 0;
    global.msg[0] = "* Please select a location./%%";
    instance_create(0, 0, obj_dialoguer);
    con = 2;
    buffer = 5;
}

if (con == 2 && instance_exists(OBJ_WRITER) == 0)
{
    buffer -= 1;
    draw_set_color(c_white);
    draw_rectangle(view_xview[view_current] + 16, view_yview[view_current] + 5, view_xview[view_current] + 304, view_yview[view_current] + 80, false);
    draw_set_color(c_black);
    draw_rectangle(view_xview[view_current] + 19, view_yview[view_current] + 8, view_xview[view_current] + 301, view_yview[view_current] + 77, false);
    draw_set_color(c_white);
    draw_set_font(fnt_maintext);
    
    if (global.flag[398] != 0)
        draw_text(view_xview[0] + 50, view_yview[0] + 15, "Left Floor 1");
    else
        draw_text(view_xview[0] + 50, view_yview[0] + 15, "Cancel");
    
    if (global.flag[398] != 1)
        draw_text(view_xview[0] + 160, view_yview[0] + 15, "Right Floor 1");
    else
        draw_text(view_xview[0] + 160, view_yview[0] + 15, "Cancel");
    
    if (global.flag[398] != 2)
        draw_text(view_xview[0] + 160, view_yview[0] + 35, "Right Floor 2");
    else
        draw_text(view_xview[0] + 160, view_yview[0] + 35, "Cancel");
    
    if (trigger > 0)
    {
        if (global.flag[398] != 3)
            draw_text(view_xview[0] + 50, view_yview[0] + 35, "Left Floor 2");
        else
            draw_text(view_xview[0] + 50, view_yview[0] + 35, "Cancel");
    }
    
    if (trigger > 0)
    {
        if (global.flag[398] != 4)
            draw_text(view_xview[0] + 50, view_yview[0] + 55, "Left Floor 3");
        else
            draw_text(view_xview[0] + 50, view_yview[0] + 55, "Cancel");
    }
    
    if (trigger > 1)
    {
        if (global.flag[398] != 5)
            draw_text(view_xview[0] + 160, view_yview[0] + 55, "Right Floor 3");
        else
            draw_text(view_xview[0] + 160, view_yview[0] + 55, "Cancel");
    }
    
    draw_sprite(spr_heartsmall, 0, view_xview[0] + 30 + (heartx * 110), view_yview[0] + 20 + (20 * hearty));
    
    if (buffer < 0)
    {
        if (keyboard_check_pressed(vk_up))
        {
            if (hearty > 0)
                hearty -= 1;
        }
        
        if (keyboard_check_pressed(vk_down))
        {
            if (hearty < 2)
            {
                if (heartx == 0)
                {
                    if (hearty == 1 && trigger > 0)
                        hearty += 1;
                    
                    if (hearty == 0 && trigger > 0)
                        hearty += 1;
                }
                
                if (heartx == 1)
                {
                    if (hearty == 1 && trigger > 1)
                        hearty += 1;
                    
                    if (hearty == 0)
                        hearty += 1;
                }
            }
        }
        
        if (keyboard_check_pressed(vk_right))
        {
            if (heartx == 0)
            {
                if (hearty == 0)
                    heartx += 1;
                
                if (hearty == 1)
                    heartx += 1;
                
                if (hearty == 2 && trigger > 1)
                    heartx += 1;
            }
        }
        
        if (keyboard_check_pressed(vk_left))
        {
            if (heartx == 1)
            {
                if (hearty == 0)
                    heartx -= 1;
                
                if (hearty == 1 && trigger > 0)
                    heartx -= 1;
                
                if (hearty == 2 && trigger > 1)
                    heartx -= 1;
            }
        }
        
        if (keyboard_multicheck_pressed(0))
        {
            con = 5;
            
            if (heartx == 0 && hearty == 0)
            {
                if (global.flag[398] != 0)
                    global.flag[398] = 0;
                else
                    con = 15;
            }
            
            if (heartx == 1 && hearty == 0)
            {
                if (global.flag[398] != 1)
                    global.flag[398] = 1;
                else
                    con = 15;
            }
            
            if (heartx == 1 && hearty == 1)
            {
                if (global.flag[398] != 2)
                    global.flag[398] = 2;
                else
                    con = 15;
            }
            
            if (heartx == 0 && hearty == 1)
            {
                if (global.flag[398] != 3)
                    global.flag[398] = 3;
                else
                    con = 15;
            }
            
            if (heartx == 0 && hearty == 2)
            {
                if (global.flag[398] != 4)
                    global.flag[398] = 4;
                else
                    con = 15;
            }
            
            if (heartx == 1 && hearty == 2)
            {
                if (global.flag[398] != 5)
                    global.flag[398] = 5;
                else
                    con = 15;
            }
        }
    }
}

if (con == 5)
{
    snd_play(snd_item);
    con = 6;
    alarm[4] = 15;
}

if (con == 7)
{
    rect = 1;
    global.facing = 0;
    snd_play(snd_bell);
    con = 8;
    alarm[4] = 11;
}

if (con == 9)
{
    caster_play(snd_elecdoor_shut, 1, 1);
    elev = caster_load("music/elevator.ogg");
    xx = view_xview[0];
    yy = view_yview[0];
    siner = 0;
    con = 10;
    intense = 0.5;
    alarm[4] = 15;
}

if (con == 11)
{
    con = 12;
    alarm[4] = 110;
    caster_play(elev, 1, 1);
}

if (con == 12)
{
    obj_mainchara.cutscene = 1;
    view_object[0] = -4;
    siner += 1;
    
    if (alarm[4] > 20)
        intense += 0.01;
    else if (intense > 0)
        intense -= 0.1;
    
    view_xview[0] = floor(xx + (sin(siner / 1.3) * intense));
    view_yview[0] = floor(yy + (sin(siner / 0.9) * intense));
}

if (con == 13)
{
    view_xview[0] = xx;
    view_yview[0] = yy;
    rect = 2;
    con = 14;
    snd_play(snd_bell);
    alarm[4] = 11;
}

if (con == 15)
{
    global.facing = 0;
    caster_play(snd_elecdoor_shut, 1, 1);
    global.interact = 0;
    con = 0;
    scr_tempsave();
    myinteract = 0;
}

if (rect == 1)
{
    if (rectaur < 20)
        rectaur += 2;
    
    draw_set_color(c_black);
    draw_rectangle(140, 180, 140 + rectaur, 250, false);
    draw_rectangle(180, 180, 180 - rectaur, 250, false);
}

if (rect == 2)
{
    if (rectaur > 0)
        rectaur -= 2;
    
    draw_set_color(c_black);
    draw_rectangle(140, 180, 140 + rectaur, 250, false);
    draw_rectangle(180, 180, 180 - rectaur, 250, false);
}
