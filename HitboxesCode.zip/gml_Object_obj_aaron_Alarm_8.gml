snd_play(hurtsound);
