if (other.type == 0)
{
    with (other)
        instance_destroy();
}
