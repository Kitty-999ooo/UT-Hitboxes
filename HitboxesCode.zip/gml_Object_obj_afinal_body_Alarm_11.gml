bcon += 1;
