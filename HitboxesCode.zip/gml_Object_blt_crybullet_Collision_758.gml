hspeed = -hspeed;
