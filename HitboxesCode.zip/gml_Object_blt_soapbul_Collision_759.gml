y -= vspeed;
vspeed = -vspeed;
